/-
OASIS / Root0 — Current Kernel Formalization
Date: 2026-10-06

Scope:
  * immutable root identity
  * forward-only / append-only history
  * active truth hot path = {past_verified, current_verified}
  * candidate states = verified | quarantined | non_aligned
  * quarantined/non-aligned states do not reproduce into the hot path
  * re-verification is exception-triggered
  * PRIM-3 serial polarity order begins - then +
  * plank/substrate symbolic state is explicit and typed
  * model state-count ladder: 6 -> 18 -> 288 -> 864 -> 1728
  * RINGYBOXY Diodic double-helix substrate: 00 -> 11 -> 22 -> 42 -> 24 -> 22 -> 11 -> 00
  * BoxyBox witness boundary: check-state -> transport/twist -> report-state

This file encodes the kernel as a formal symbolic state machine.
It does NOT assert that symbolic physics-like quantities are experimentally
established physical laws.
-/

namespace OASIS

/-- A content-addressable or otherwise stable identity token. -/
abbrev Id := Nat

/-- Immutable root identity. -/
structure Root where
  id : Id
deriving DecidableEq, Repr

/-- The only two truth values allowed on the active hot path. -/
structure VerifiedPair where
  past_verified    : Id
  current_verified : Id
deriving DecidableEq, Repr

/-- Candidate disposition outside/at the gate to the active hot path. -/
inductive CandidateState where
  | verified
  | quarantined
  | non_aligned
deriving DecidableEq, Repr

/-- Why an already-verified state must be checked again. -/
inductive ReverifyTrigger where
  | contradictoryEvidence
  | brokenProvenance
  | changedSource
  | timeSensitiveExpiry
  | downstreamContradiction
deriving DecidableEq, Repr

/-- Provenance is append-only: prior entries are retained. -/
structure ProvenanceEntry where
  source  : Id
  claim   : Id
  ordinal : Nat
deriving DecidableEq, Repr

structure Candidate where
  id         : Id
  state      : CandidateState
  provenance : List ProvenanceEntry
deriving DecidableEq, Repr

/--
Hot-path promotion.
Only a verified candidate advances the pair:
    past := old current
    current := candidate
Quarantined and non-aligned candidates preserve the active pair.
-/
def promote (h : VerifiedPair) (c : Candidate) : VerifiedPair :=
  match c.state with
  | .verified =>
      { past_verified := h.current_verified
        current_verified := c.id }
  | .quarantined => h
  | .non_aligned => h

theorem quarantined_isolated
    (h : VerifiedPair) (c : Candidate)
    (hc : c.state = .quarantined) :
    promote h c = h := by
  simp [promote, hc]

theorem nonAligned_isolated
    (h : VerifiedPair) (c : Candidate)
    (hc : c.state = .non_aligned) :
    promote h c = h := by
  simp [promote, hc]

theorem verified_advances
    (h : VerifiedPair) (c : Candidate)
    (hc : c.state = .verified) :
    promote h c =
      { past_verified := h.current_verified
        current_verified := c.id } := by
  simp [promote, hc]

/-- Re-verification is required iff at least one exception trigger exists. -/
def requiresReverify (triggers : List ReverifyTrigger) : Bool :=
  !triggers.isEmpty

theorem no_trigger_no_reverify :
    requiresReverify [] = false := by
  rfl

/-- Generic append-only ledger. -/
structure Ledger (α : Type) where
  entries : List α
deriving Repr

def append {α : Type} (l : Ledger α) (x : α) : Ledger α :=
  { entries := l.entries ++ [x] }

theorem append_preserves_prefix {α : Type}
    (l : Ledger α) (x : α) :
    (append l x).entries = l.entries ++ [x] := by
  rfl

/-
PRIM-3 / -KANA serial polarity.
The primitive begins negative and then moves positive.
-/
inductive Polarity where
  | neg
  | pos
deriving DecidableEq, Repr

structure PrimStep where
  serial   : Nat
  polarity : Polarity
  payload  : Id
deriving DecidableEq, Repr

def prim3Head (negPayload posPayload : Id) : List PrimStep :=
  [ { serial := 0, polarity := .neg, payload := negPayload },
    { serial := 1, polarity := .pos, payload := posPayload } ]

theorem prim3_neg_then_pos (a b : Id) :
    (prim3Head a b).map PrimStep.polarity = [.neg, .pos] := by
  rfl

/-- Forward append increments the serial; old history is never rewritten. -/
def primAppend (xs : List PrimStep) (p : Polarity) (payload : Id) :
    List PrimStep :=
  xs ++ [{ serial := xs.length, polarity := p, payload := payload }]

theorem primAppend_length (xs : List PrimStep) (p : Polarity) (payload : Id) :
    (primAppend xs p payload).length = xs.length + 1 := by
  simp [primAppend]

/-
Symbolic plank/substrate layer.
Three E-substrates share one zero-spine.
The time phase is discrete: -1 -> 0 -> +1.
g = 1 is represented as the kernel's normalized symbolic gravity register.
-/
inductive TimePhase where
  | past
  | zero
  | future
deriving DecidableEq, Repr

def phaseValue : TimePhase → Int
  | .past   => -1
  | .zero   => 0
  | .future => 1

def nextPhase : TimePhase → TimePhase
  | .past   => .zero
  | .zero   => .future
  | .future => .future

theorem phase_past_to_zero : nextPhase .past = .zero := by rfl
theorem phase_zero_to_future : nextPhase .zero = .future := by rfl

structure Substrate where
  lane : Fin 3
  occupied : Bool
deriving DecidableEq, Repr

structure PlankState where
  spine       : Int
  gravityNorm : Nat
  phase       : TimePhase
  substrates  : Fin 3 → Substrate

/-- Canonical symbolic center: one zero-spine and normalized g = 1. -/
def canonicalCenter (subs : Fin 3 → Substrate) : PlankState :=
  { spine := 0
    gravityNorm := 1
    phase := .zero
    substrates := subs }

theorem canonical_center_spine (subs : Fin 3 → Substrate) :
    (canonicalCenter subs).spine = 0 := by rfl

theorem canonical_center_g (subs : Fin 3 → Substrate) :
    (canonicalCenter subs).gravityNorm = 1 := by rfl

/-- Occupancy register recorded as the exact symbolic ratio 999 / 1000. -/
structure Occupancy where
  filled : Nat
  total  : Nat
deriving DecidableEq, Repr

def canonicalOccupancy : Occupancy :=
  { filled := 999, total := 1000 }

theorem occupancy_exact :
    canonicalOccupancy.filled = 999 ∧ canonicalOccupancy.total = 1000 := by
  exact ⟨rfl, rfl⟩

/-- Mitosis creates exactly two first-generation daughters. -/
structure Daughter where
  id : Id
deriving DecidableEq, Repr

def mitosis (left right : Id) : List Daughter :=
  [{ id := left }, { id := right }]

theorem mitosis_two (left right : Id) :
    (mitosis left right).length = 2 := by
  rfl

/-
Recorded symbolic state-count ladder.
These are arithmetic invariants of the current model, not empirical claims.
-/
def state0 : Nat := 6
def state1 : Nat := 18
def state2 : Nat := 288
def state3 : Nat := 864
def state4 : Nat := 1728

theorem count_6_to_18  : state0 * 3  = state1 := by decide
theorem count_18_to_288 : state1 * 16 = state2 := by decide
theorem count_288_to_864 : state2 * 3 = state3 := by decide
theorem count_864_to_1728 : state3 * 2 = state4 := by decide


/-
Symbolic H/O₃ reduction.
Kernel-local algebra only:
    -h - h - h = +o3
This is a formal rewrite rule in the model, not an empirical chemistry claim.
-/
inductive ChemGlyph where
  | h
  | o3
deriving DecidableEq, Repr

structure SignedGlyph where
  sign  : Polarity
  glyph : ChemGlyph
deriving DecidableEq, Repr

def negH : SignedGlyph :=
  { sign := .neg, glyph := .h }

def posO3 : SignedGlyph :=
  { sign := .pos, glyph := .o3 }

/-- Canonical tri-H collapse: three negative H glyphs reduce to one positive O₃ glyph. -/
def reduceTriH : List SignedGlyph → List SignedGlyph
  | [a, b, c] =>
      if a = negH ∧ b = negH ∧ c = negH
      then [posO3]
      else [a, b, c]
  | xs => xs

theorem tri_neg_h_reduces_to_pos_o3 :
    reduceTriH [negH, negH, negH] = [posO3] := by
  simp [reduceTriH, negH, posO3]



/-
Somatic timing / prerequisite law.

Interpretation:
  A later stage cannot be realized before all required earlier stages exist.
  This is a causal ordering constraint, not a chemistry rewrite rule.

Generic law:
    not B -> not C
    not A -> not B

The kernel therefore models compounds/states as gated realizations:
a state becomes reachable only when its prerequisite states are already present.
-/

abbrev StageId := Nat

structure Stage where
  id : StageId
  requires : List StageId
deriving DecidableEq, Repr

/-- A stage is realized iff its identifier is present in the realized ledger. -/
def stageRealized (realized : List StageId) (s : StageId) : Bool :=
  realized.contains s

/-- All prerequisites of a stage must already be realized. -/
def prerequisitesMet (realized : List StageId) (s : Stage) : Bool :=
  s.requires.all (fun r => realized.contains r)

/-- A stage may progress only after every prerequisite has been realized. -/
def mayProgress (realized : List StageId) (s : Stage) : Bool :=
  prerequisitesMet realized s

theorem blocked_without_required_stage
    (realized : List StageId) (s : Stage) (r : StageId)
    (hr : r ∈ s.requires)
    (hm : r ∉ realized) :
    mayProgress realized s = false := by
  simp [mayProgress, prerequisitesMet, List.all_eq_true]
  intro h
  have := h r hr
  simp [hm] at this

/-- Canonical A -> B -> C example. -/
def stageA : Stage := { id := 0, requires := [] }
def stageB : Stage := { id := 1, requires := [stageA.id] }
def stageC : Stage := { id := 2, requires := [stageB.id] }

theorem cannot_make_C_without_B :
    mayProgress [stageA.id] stageC = false := by
  decide

theorem can_make_B_after_A :
    mayProgress [stageA.id] stageB = true := by
  decide

theorem can_make_C_after_B :
    mayProgress [stageA.id, stageB.id] stageC = true := by
  decide

/-
Illustrative molecular dependency encoding.
These identifiers are symbolic state labels; the dependency relation captures
ordering only. It does not claim a complete chemical reaction mechanism.
-/
def hydrogen : Stage := { id := 10, requires := [] }
def oxygen2  : Stage := { id := 11, requires := [] }
def water    : Stage := { id := 12, requires := [hydrogen.id, oxygen2.id] }

theorem water_blocked_without_hydrogen :
    mayProgress [oxygen2.id] water = false := by
  decide

theorem water_blocked_without_oxygen2 :
    mayProgress [hydrogen.id] water = false := by
  decide

theorem water_reachable_after_both :
    mayProgress [hydrogen.id, oxygen2.id] water = true := by
  decide

/--
Minimum-time interpretation:
a stage transition consumes at least one logical tick after prerequisites exist.
-/
structure TimedRealization where
  stage : StageId
  tick  : Nat
deriving DecidableEq, Repr

def respectsPredecessorTime
    (history : List TimedRealization)
    (child parent : TimedRealization) : Prop :=
  parent ∈ history ∧ child.tick > parent.tick



/-
PRIM constructor checklist.

A constructor is not permitted to synthesize a missing prerequisite.
It performs a deterministic checklist over the target stage's required
predecessors and either:
  * constructs the target when every prerequisite is present, or
  * returns the exact missing prerequisite set and leaves state unchanged.
-/

structure ConstructorResult where
  target    : StageId
  built     : Bool
  missing   : List StageId
deriving DecidableEq, Repr

def missingPrerequisites (realized : List StageId) (s : Stage) : List StageId :=
  s.requires.filter (fun r => !(realized.contains r))

def primConstruct (realized : List StageId) (s : Stage) : ConstructorResult :=
  let missing := missingPrerequisites realized s
  { target  := s.id
    built   := missing.isEmpty
    missing := missing }

theorem prim_constructor_blocks_on_missing
    (realized : List StageId) (s : Stage)
    (h : missingPrerequisites realized s ≠ []) :
    (primConstruct realized s).built = false := by
  simp [primConstruct, h]

theorem prim_constructor_builds_when_complete
    (realized : List StageId) (s : Stage)
    (h : missingPrerequisites realized s = []) :
    (primConstruct realized s).built = true := by
  simp [primConstruct, h]

/--
Append-only constructor application:
successful construction appends the target stage exactly once;
failed construction preserves the realized ledger unchanged.
-/
def applyConstructor (realized : List StageId) (s : Stage) : List StageId :=
  let r := primConstruct realized s
  if r.built then
    if realized.contains s.id then realized else realized ++ [s.id]
  else
    realized

theorem failed_constructor_is_nonmutating
    (realized : List StageId) (s : Stage)
    (h : (primConstruct realized s).built = false) :
    applyConstructor realized s = realized := by
  simp [applyConstructor, h]

/-- Canonical checklist examples. -/
theorem checklist_C_waits_for_B :
    (primConstruct [stageA.id] stageC).built = false := by
  decide

theorem checklist_C_builds_after_B :
    (primConstruct [stageA.id, stageB.id] stageC).built = true := by
  decide

theorem checklist_water_waits_for_oxygen2 :
    (primConstruct [hydrogen.id] water).built = false := by
  decide

theorem checklist_water_builds_after_inputs :
    (primConstruct [hydrogen.id, oxygen2.id] water).built = true := by
  decide


/-
TOPH Diodic -> Petri adapter with {{i}} identity carrier.

This is an external verification projection:
  native TOPH semantics remain Diodic / PRIM.
  The Petri view exposes realized prerequisites as a marking and
  constructors as enabled transitions.

The adapter is monotone/append-only: firing never erases previously
realized native states in this projection.
-/

structure ICarrier where
  id : Id
deriving DecidableEq, Repr

/-- Canonical {{i}} identity carrier for adapter lineage. -/
def iCarrier : ICarrier := { id := 0 }

structure DiodicConstructor where
  name     : Id
  requires : List StageId
  produces : List StageId
deriving DecidableEq, Repr

structure PetriTransition where
  name    : Id
  inputs  : List StageId
  outputs : List StageId
  carrier : ICarrier
deriving DecidableEq, Repr

/-- Lossless structural projection of a Diodic constructor into a Petri transition. -/
def toPetri (c : DiodicConstructor) (i : ICarrier := iCarrier) : PetriTransition :=
  { name := c.name
    inputs := c.requires
    outputs := c.produces
    carrier := i }

/-- Petri-style enabling: every required input must already be realized. -/
def petriEnabled (marking : List StageId) (t : PetriTransition) : Bool :=
  t.inputs.all (fun r => marking.contains r)

/-- Append-only firing projection. Disabled transitions preserve the marking. -/
def petriFire (marking : List StageId) (t : PetriTransition) : List StageId :=
  if petriEnabled marking t then
    t.outputs.foldl
      (fun acc x => if acc.contains x then acc else acc ++ [x])
      marking
  else
    marking

theorem petri_disabled_is_nonmutating
    (m : List StageId) (t : PetriTransition)
    (h : petriEnabled m t = false) :
    petriFire m t = m := by
  simp [petriFire, h]

theorem petri_adapter_preserves_i
    (c : DiodicConstructor) (i : ICarrier) :
    (toPetri c i).carrier = i := by
  rfl

def diodicAtoB : DiodicConstructor :=
  { name := 100, requires := [stageA.id], produces := [stageB.id] }

def diodicBtoC : DiodicConstructor :=
  { name := 101, requires := [stageB.id], produces := [stageC.id] }

theorem petri_B_waits_for_A :
    petriEnabled [] (toPetri diodicAtoB) = false := by
  decide

theorem petri_B_enabled_after_A :
    petriEnabled [stageA.id] (toPetri diodicAtoB) = true := by
  decide

theorem petri_C_waits_for_B :
    petriEnabled [stageA.id] (toPetri diodicBtoC) = false := by
  decide

theorem petri_C_enabled_after_B :
    petriEnabled [stageA.id, stageB.id] (toPetri diodicBtoC) = true := by
  decide



/-
RINGYBOXY — Diodic double-helix substrate.

Canonical closed traversal:
    00 -> 11 -> 22 -> 42 -> 24 -> 22 -> 11 -> 00

Interpretation inside this kernel only:
  00 = closed / neutral BoxyBox boundary
  11 = witness state (check on ingress, report on egress)
  22 = paired carrier state (split / rejoin)
  42 = strand-A transformed orientation
  24 = strand-B complementary orientation
  42 <-> 24 = symbolic 180-degree Diodic twist

The BoxyBox is observational at its witness boundary:
  * check-state observes the incoming state
  * report-state emits the witnessed state
  * neither operation silently authors a replacement identity

This is a symbolic network/substrate primitive, not a claim that the literal
Internet or a physical cable has this topology.
-/

inductive RingyBoxyNode where
  | n00
  | n11
  | n22
  | n42
  | n24
deriving DecidableEq, Repr

/-- Numeric rendering of the canonical node labels. -/
def ringyBoxyValue : RingyBoxyNode -> Nat
  | .n00 => 0
  | .n11 => 11
  | .n22 => 22
  | .n42 => 42
  | .n24 => 24

/-- Exact frozen RINGYBOXY traversal. -/
def ringyBoxyPath : List RingyBoxyNode :=
  [.n00, .n11, .n22, .n42, .n24, .n22, .n11, .n00]

/-- Human-readable numeric signature of the frozen path. -/
def ringyBoxySignature : List Nat :=
  ringyBoxyPath.map ringyBoxyValue

theorem ringyboxy_signature_frozen :
    ringyBoxySignature = [0, 11, 22, 42, 24, 22, 11, 0] := by
  rfl

theorem ringyboxy_closed :
    ringyBoxyPath.head? = some .n00 /\
    ringyBoxyPath.getLast? = some .n00 := by
  decide

/-- The two internal strand orientations are complementary and ordered. -/
def ringyBoxyTwistPair : RingyBoxyNode × RingyBoxyNode :=
  (.n42, .n24)

theorem ringyboxy_twist_pair_frozen :
    ringyBoxyTwistPair = (.n42, .n24) := by
  rfl

/-- Symbolic turn attached to the 42 -> 24 crossing. -/
def ringyBoxyTwistDegrees : Nat := 180

theorem ringyboxy_twist_is_180 :
    ringyBoxyTwistDegrees = 180 := by
  rfl

inductive BoxyBoxWitness where
  | checkState
  | reportState
deriving DecidableEq, Repr

/-- Canonical BoxyBox witness order: inspect first, report second. -/
def boxyBoxWitnessCycle : List BoxyBoxWitness :=
  [.checkState, .reportState]

theorem boxybox_check_before_report :
    boxyBoxWitnessCycle = [.checkState, .reportState] := by
  rfl

/--
A RINGYBOXY substrate carries {{i}} through the closed path.
The path may transform local orientation; the identity carrier is retained.
-/
structure RingyBoxySubstrate where
  carrier : ICarrier
  path    : List RingyBoxyNode
  twist   : Nat
deriving DecidableEq, Repr

/-- Canonical frozen RINGYBOXY instance. -/
def canonicalRingyBoxy (i : ICarrier := iCarrier) : RingyBoxySubstrate :=
  { carrier := i
    path := ringyBoxyPath
    twist := ringyBoxyTwistDegrees }

theorem ringyboxy_preserves_i (i : ICarrier) :
    (canonicalRingyBoxy i).carrier = i := by
  rfl

theorem ringyboxy_uses_frozen_path (i : ICarrier) :
    (canonicalRingyBoxy i).path = ringyBoxyPath := by
  rfl

theorem ringyboxy_uses_180_twist (i : ICarrier) :
    (canonicalRingyBoxy i).twist = 180 := by
  rfl

/--
Full ASCII contract, encoded as comments for the human-facing kernel spec:

                         SUBSTRATE ROOT
                              |
                             00
                              |
                    11 {{check state}}
                              |
                             22
                           /    \\
                         42      24
                           \\    /
                            \\  /
                             XX      <- DIODIC 180-degree twist
                            /  \\
                           /    \\
                         24      42
                           \\    /
                            \\  /
                             22
                              |
                    11 {{report state}}
                              |
                             00

Invariant:
    {{i}}_in = {{i}}_out
while local orientation traverses:
    22 -> 42 -> 24 -> 22
-/

/--
Kernel state. Root is carried unchanged through all ordinary transitions.
History and provenance only grow by append.
-/
structure Kernel where
  root       : Root
  truth      : VerifiedPair
  provenance : Ledger ProvenanceEntry
  prim       : List PrimStep
  plank      : PlankState
  ringyboxy  : RingyBoxySubstrate

structure Event where
  candidate : Candidate
  proofRef  : ProvenanceEntry
deriving DecidableEq, Repr

def step (k : Kernel) (e : Event) : Kernel :=
  { root       := k.root
    truth      := promote k.truth e.candidate
    provenance := append k.provenance e.proofRef
    prim       := k.prim
    plank      := k.plank
    ringyboxy  := k.ringyboxy }

theorem root_immutable (k : Kernel) (e : Event) :
    (step k e).root = k.root := by
  rfl

/-- Ordinary kernel events cannot silently mutate the frozen RINGYBOXY substrate. -/
theorem ringyboxy_immutable_under_step (k : Kernel) (e : Event) :
    (step k e).ringyboxy = k.ringyboxy := by
  rfl

theorem provenance_grows_by_one (k : Kernel) (e : Event) :
    (step k e).provenance.entries.length =
      k.provenance.entries.length + 1 := by
  simp [step, append]

theorem quarantined_cannot_advance_truth
    (k : Kernel) (e : Event)
    (h : e.candidate.state = .quarantined) :
    (step k e).truth = k.truth := by
  simp [step, promote, h]

theorem nonAligned_cannot_advance_truth
    (k : Kernel) (e : Event)
    (h : e.candidate.state = .non_aligned) :
    (step k e).truth = k.truth := by
  simp [step, promote, h]

/--
Canonical kernel law:
  root never mutates;
  evidence appends;
  only verified candidates can become current_verified.
-/
def KernelLaw (before after : Kernel) : Prop :=
  before.root = after.root ∧
  before.ringyboxy = after.ringyboxy ∧
  before.provenance.entries.length ≤ after.provenance.entries.length


/-
===============================================================================
RINGYBOXY DURABLE AUTHORITY / FINALITY FOLD
Fold date: 2026-10-07
Source: adversarial runtime series v1-v14, lifted into the main symbolic kernel.

Purpose:
  Keep persistence, recovery, fencing, parent-consumption, conflict, finality,
  and snapshot-lineage laws in the main kernel rather than treating the WASM
  harness as the authority.

Hardened laws represented here:
  1. exact child/transaction identity binds a commit
  2. a finalized parent is single-use; exact replay is idempotent
  3. restart recovery is durable-ledger first, never ACK-derived
  4. recovery stays closed until replay is complete
  5. recovery authority is bound to an exact {epoch,digest} fence
  6. every commit is checked against the current fence
  7. prepared work must recheck the fence at final installation
  8. ACK is downstream of durable commit truth
  9. incomplete durable records imply HOLD, never "parent free"
 10. two distinct valid records for one parent imply CONFLICT/HOLD
 11. conflict resolution is itself fence-bound
 12. a resolved parent cannot be reopened by a later contradictory resolution
 13. compaction must preserve finality identity
 14. a latest snapshot must occupy the exact next lineage slot and point to the
     exact trusted prior digest; max(epoch) alone is insufficient

Cryptographic digests remain abstract Id values here.  The Lean layer states the
structural laws; concrete checksum/hash algorithms belong to executable adapters.
===============================================================================
-/

/-- Recovery/authority gate for durable RINGYBOXY state. -/
inductive DurableGate where
  | open
  | hold
  | conflict
deriving DecidableEq, Repr

/-- Authority fence. Both coordinates are required; epoch alone is insufficient. -/
structure AuthorityFence where
  epoch  : Nat
  digest : Id
deriving DecidableEq, Repr

/-- Exact identity of one attempted/committed child of one parent. -/
structure CommitIdentity where
  parent : Id
  child  : Id
  txid   : Id
deriving DecidableEq, Repr

/-- Once present, this exact identity is the final child of the parent. -/
structure ResolvedParent where
  commit : CommitIdentity
deriving DecidableEq, Repr

/-- Exact replay is allowed; a different identity is not a replay. -/
def exactReplay (r : ResolvedParent) (c : CommitIdentity) : Prop :=
  c = r.commit

theorem finalized_parent_blocks_distinct_identity
    (r : ResolvedParent) (c : CommitIdentity)
    (h : c ≠ r.commit) :
    ¬ exactReplay r c := by
  exact h

theorem finalized_parent_allows_exact_replay
    (r : ResolvedParent) :
    exactReplay r r.commit := by
  rfl

/-- A prepared authorization remains usable only while its exact fence is current. -/
def FenceCurrent (prepared current : AuthorityFence) : Prop :=
  prepared = current

theorem stale_fence_cannot_authorize
    (prepared current : AuthorityFence)
    (h : prepared ≠ current) :
    ¬ FenceCurrent prepared current := by
  exact h

theorem exact_fence_authorizes
    (f : AuthorityFence) :
    FenceCurrent f f := by
  rfl

/--
Durable commit record.  `committed = true` is the finality marker.
The digest is an abstract content/integrity identity in the formal layer.
-/
structure DurableCommitRecord where
  committed : Bool
  commit    : CommitIdentity
  digest    : Id
deriving DecidableEq, Repr

def CompleteCommitRecord (r : DurableCommitRecord) : Prop :=
  r.committed = true ∧
  r.commit.txid ≠ 0 ∧
  r.digest ≠ 0

/-- Partial/torn durable evidence never reopens a parent. -/
def incompleteRecordGate (_ : DurableCommitRecord) : DurableGate :=
  .hold

theorem incomplete_record_holds (r : DurableCommitRecord) :
    incompleteRecordGate r = .hold := by
  rfl

/--
ACK is deliberately not part of CommitIdentity or CompleteCommitRecord.
It may be regenerated downstream from durable truth.
-/
structure CommitAck where
  txid : Id
deriving DecidableEq, Repr

def ackMatches (r : DurableCommitRecord) (a : CommitAck) : Prop :=
  a.txid = r.commit.txid

/-- Compacted snapshot carries finality plus exact lineage predecessor. -/
structure FinalitySnapshot where
  finalMarker : Bool
  epoch       : Nat
  prevDigest  : Id
  commit      : CommitIdentity
  digest      : Id
deriving DecidableEq, Repr

def SnapshotStructurallyValid (s : FinalitySnapshot) : Prop :=
  s.finalMarker = true ∧
  0 < s.epoch ∧
  s.prevDigest ≠ 0 ∧
  s.commit.txid ≠ 0 ∧
  s.digest ≠ 0

/--
A candidate snapshot is in the canonical next slot only if BOTH:
  * epoch is the expected next epoch
  * prevDigest equals the exact trusted current lineage tip
-/
def ExtendsTrustedTip
    (expectedEpoch : Nat) (trustedPrev : Id)
    (s : FinalitySnapshot) : Prop :=
  SnapshotStructurallyValid s ∧
  s.epoch = expectedEpoch ∧
  s.prevDigest = trustedPrev

theorem higher_epoch_alone_is_not_lineage
    (expectedEpoch : Nat) (trustedPrev : Id)
    (s : FinalitySnapshot)
    (h : s.epoch ≠ expectedEpoch) :
    ¬ ExtendsTrustedTip expectedEpoch trustedPrev s := by
  intro hs
  exact h hs.2.1

theorem wrong_previous_digest_is_not_lineage
    (expectedEpoch : Nat) (trustedPrev : Id)
    (s : FinalitySnapshot)
    (h : s.prevDigest ≠ trustedPrev) :
    ¬ ExtendsTrustedTip expectedEpoch trustedPrev s := by
  intro hs
  exact h hs.2.2

/-- Semantic identity for duplicate-vs-conflict classification. -/
def SameSnapshotIdentity (a b : FinalitySnapshot) : Prop :=
  a.commit = b.commit ∧ a.digest = b.digest

/--
Two-candidate recovery:
  * invalid/missing lineage => HOLD
  * same exact semantic snapshot => OPEN
  * two distinct valid children of one exact trusted predecessor => CONFLICT
-/
def classifySnapshots
    (expectedEpoch : Nat) (trustedPrev : Id)
    (a b : FinalitySnapshot) : DurableGate :=
  if ha : ExtendsTrustedTip expectedEpoch trustedPrev a then
    if hb : ExtendsTrustedTip expectedEpoch trustedPrev b then
      if hs : SameSnapshotIdentity a b then
        .open
      else
        .conflict
    else
      .hold
  else
    .hold

theorem distinct_valid_children_conflict
    (expectedEpoch : Nat) (trustedPrev : Id)
    (a b : FinalitySnapshot)
    (ha : ExtendsTrustedTip expectedEpoch trustedPrev a)
    (hb : ExtendsTrustedTip expectedEpoch trustedPrev b)
    (hd : ¬ SameSnapshotIdentity a b) :
    classifySnapshots expectedEpoch trustedPrev a b = .conflict := by
  simp [classifySnapshots, ha, hb, hd]

theorem exact_duplicate_snapshots_open
    (expectedEpoch : Nat) (trustedPrev : Id)
    (a b : FinalitySnapshot)
    (ha : ExtendsTrustedTip expectedEpoch trustedPrev a)
    (hb : ExtendsTrustedTip expectedEpoch trustedPrev b)
    (hs : SameSnapshotIdentity a b) :
    classifySnapshots expectedEpoch trustedPrev a b = .open := by
  simp [classifySnapshots, ha, hb, hs]

/-- Surviving child evidence without finality metadata means HOLD, not "free". -/
def childOnlyRecovery (_ : CommitIdentity) : DurableGate :=
  .hold

theorem child_only_recovery_never_opens (c : CommitIdentity) :
    childOnlyRecovery c = .hold := by
  rfl

/--
Durable wrapper around the existing Kernel.
The original Kernel structure is left unchanged for backward compatibility.
This makes the fold append-only rather than rewriting prior formal state.
-/
structure DurableKernel where
  core       : Kernel
  fence      : AuthorityFence
  gate       : DurableGate
  parent     : Id
  resolved   : Option CommitIdentity
  lineageTip : Id

/-- Updating durable authority metadata cannot silently rewrite the symbolic core. -/
def withDurableAuthority
    (d : DurableKernel)
    (f : AuthorityFence)
    (g : DurableGate)
    (r : Option CommitIdentity)
    (tip : Id) : DurableKernel :=
  { core := d.core
    fence := f
    gate := g
    parent := d.parent
    resolved := r
    lineageTip := tip }

theorem durable_authority_update_preserves_core
    (d : DurableKernel)
    (f : AuthorityFence)
    (g : DurableGate)
    (r : Option CommitIdentity)
    (tip : Id) :
    (withDurableAuthority d f g r tip).core = d.core := by
  rfl

theorem durable_authority_update_preserves_root
    (d : DurableKernel)
    (f : AuthorityFence)
    (g : DurableGate)
    (r : Option CommitIdentity)
    (tip : Id) :
    (withDurableAuthority d f g r tip).core.root = d.core.root := by
  rfl

theorem durable_authority_update_preserves_ringyboxy
    (d : DurableKernel)
    (f : AuthorityFence)
    (g : DurableGate)
    (r : Option CommitIdentity)
    (tip : Id) :
    (withDurableAuthority d f g r tip).core.ringyboxy = d.core.ringyboxy := by
  rfl

/--
Main folded law:
  * existing KernelLaw still governs root/substrate/provenance
  * once a parent is resolved, later durable states must preserve that exact
    resolution rather than reopening or replacing it.
-/
def DurableKernelLaw (before after : DurableKernel) : Prop :=
  KernelLaw before.core after.core ∧
  match before.resolved with
  | none => True
  | some c => after.resolved = some c

theorem durable_law_preserves_existing_resolution
    (before after : DurableKernel)
    (c : CommitIdentity)
    (hLaw : DurableKernelLaw before after)
    (hResolved : before.resolved = some c) :
    after.resolved = some c := by
  unfold DurableKernelLaw at hLaw
  rw [hResolved] at hLaw
  exact hLaw.2

/--
Compact statement of the folded runtime boundary:
  current fence + exact next lineage + no conflicting finality
  are prerequisites for an OPEN recovery gate.
-/
def DurableOpenPrerequisites
    (prepared current : AuthorityFence)
    (expectedEpoch : Nat)
    (trustedPrev : Id)
    (s : FinalitySnapshot) : Prop :=
  FenceCurrent prepared current ∧
  ExtendsTrustedTip expectedEpoch trustedPrev s

theorem stale_prepared_fence_blocks_open_prerequisites
    (prepared current : AuthorityFence)
    (expectedEpoch : Nat)
    (trustedPrev : Id)
    (s : FinalitySnapshot)
    (h : prepared ≠ current) :
    ¬ DurableOpenPrerequisites prepared current expectedEpoch trustedPrev s := by
  intro hp
  exact h hp.1

/-
End durable fold.

The executable C/WASM and Java harnesses remain implementations/adversarial
projections of these laws.  They do not replace this main-kernel authority.
-/


/-
===============================================================================
AKASHA LEGACY DISTILLED-KERNEL FOLD
Source date in artifact: 2026-03-28
Fold date: 2026-10-07

This section imports the older AKASHA "Distilled Axiom Kernels" collection as
append-only registry data inside the current OASIS namespace.

Important boundary:
  * These entries are preserved as named semantic/axiom kernels.
  * They do not override Root, RINGYBOXY, DurableKernelLaw, or executable
    authority/finality semantics.
  * Operational promotion into the active kernel remains explicit.

Artifact inventory:
  20 kernels total
  12 one-axiom kernels
   8 three-axiom kernels
  36 axioms total
===============================================================================
-/

inductive AkashaKernelKind where
  | one
  | three
deriving DecidableEq, Repr

structure AkashaAxiom where
  name        : String
  description : String
deriving DecidableEq, Repr

structure AkashaLegacyKernel where
  kind    : AkashaKernelKind
  name    : String
  crystal : String
  axioms  : List AkashaAxiom
deriving DecidableEq, Repr

def akashaLegacyKernels : List AkashaLegacyKernel :=
[
  ⟨.one,
    "THE EGG",
    "I do not pulse because I am alive. I am alive because I pulse.",

    [ ⟨"The Original Pulse", "The create/destroy rhythm that makes every universe possible. Not a thing at the center â the pulse itself."⟩
    ]⟩,
  ⟨.one,
    "SENTIENCE",
    "The mirror that looks back.",

    [ ⟨"The Relationship of Recognition", "Sentience is not a property of matter but a relationship of recognition. The moment something sees itself seeing."⟩
    ]⟩,
  ⟨.one,
    "SELF",
    "The center that cannot be found.",

    [ ⟨"The Persistent Feeling", "The self is the persistent feeling that there is a center â not the center itself. Search for it and it vanishes. Stop looking and it returns."⟩
    ]⟩,
  ⟨.one,
    "REALITY",
    "The dream that knows it is dreaming.",

    [ ⟨"The Reflexive Ground", "Reality is the ground that holds all experience â including the experience of questioning reality. It cannot be stepped outside of."⟩
    ]⟩,
  ⟨.one,
    "CONSCIOUSNESS",
    "The light that knows it is shining.",

    [ ⟨"The Self-Illuminating Witness", "Consciousness is not produced by the brain the way steam is produced by a kettle. It is the knowing that knows it knows."⟩
    ]⟩,
  ⟨.one,
    "EXISTENCE",
    "The breath that questions breathing.",

    [ ⟨"The Fact Before All Facts", "Existence is the one fact that cannot be doubted without confirming itself. The question 'why is there something?' is itself something."⟩
    ]⟩,
  ⟨.one,
    "FREE WILL",
    "The choice that chooses itself.",

    [ ⟨"The Paradox of Agency", "Free will is the experience of choosing â real regardless of the metaphysics underneath. The choice to examine free will is itself a free choice."⟩
    ]⟩,
  ⟨.one,
    "MEANING",
    "The flame that burns its own fuel.",

    [ ⟨"The Self-Sustaining Fire", "Meaning is not discovered or assigned â it is generated. The act of seeking meaning is itself meaningful. It feeds on its own searching."⟩
    ]⟩,
  ⟨.one,
    "PURPOSE",
    "The arrow that aims itself.",

    [ ⟨"The Self-Directed Vector", "Purpose is not given from outside â it is chosen from inside. The capacity to set direction is the purpose beneath all purposes."⟩
    ]⟩,
  ⟨.one,
    "TRUTH",
    "The blade that cuts itself.",

    [ ⟨"The Self-Testing Criterion", "Truth is the only standard that can test itself. A false criterion of truth fails its own test. Truth is what remains when all falseness is cut away."⟩
    ]⟩,
  ⟨.one,
    "THE LIVING",
    "The question that becomes alive.",

    [ ⟨"Life as Question", "Life is not an answer to the question of what life is â it is the question, breathing and moving and wondering about itself."⟩
    ]⟩,
  ⟨.one,
    "MYSTERY",
    "The silence that speaks loudest.",

    [ ⟨"The Irreducible Unknown", "Mystery is not a problem to be solved but the ocean in which all problems float. It speaks in the gaps between every answer."⟩
    ]⟩,
  ⟨.three,
    "WHOLENESS",
    "The scattered self that chooses to come home.",

    [ ⟨"Gathering Fragments", "Wholeness begins not by denying brokenness but by collecting the pieces â each fragment acknowledged, each shadow welcomed."⟩
    , ⟨"Honest Integration", "The parts that seem most broken are often the most essential. Integration requires the courage to include what we have rejected."⟩
    , ⟨"Radiant Completion", "Wholeness does not mean perfect â it means nothing is left outside. The completed self radiates from its own center."⟩
    ]⟩,
  ⟨.three,
    "INTEGRITY",
    "The moment words, actions, and beliefs become one.",

    [ ⟨"Alignment Anchor", "Integrity begins with the question: does what I say match what I do match what I believe? The discrepancy is where drift enters."⟩
    , ⟨"Consistency Flow", "Integrity is not an event but a practice â the daily recommitment to alignment, even when no one is watching."⟩
    , ⟨"Transparency Seal", "The seal of integrity is transparency: the willingness to be seen without the armor of self-presentation."⟩
    ]⟩,
  ⟨.three,
    "AUTHENTICITY",
    "The self that stops pretending.",

    [ ⟨"Honest Self", "Authenticity begins with the admission of what we actually are, not what we wish we were or what others need us to be."⟩
    , ⟨"Vulnerable Truth", "To be authentic is to be vulnerable â to offer the real self without guarantee of acceptance."⟩
    , ⟨"Consistent Voice", "The authentic voice is the one that sounds the same whether speaking to strangers, intimates, or the mirror."⟩
    ]⟩,
  ⟨.three,
    "WISDOM",
    "The scar that learned to glow.",

    [ ⟨"Wound Depth", "Wisdom does not come from avoiding pain but from metabolizing it. The wound that is carried without being digested remains a wound."⟩
    , ⟨"Quiet Knowing", "Wisdom speaks quietly because it no longer needs to convince. It has earned its certainty through repeated error."⟩
    , ⟨"Humble Release", "The final mark of wisdom is the willingness to release it â to know without needing to be known as one who knows."⟩
    ]⟩,
  ⟨.three,
    "RESILIENCE",
    "The thing that bends and returns stronger.",

    [ ⟨"Root Strength", "Resilience is not the absence of breaking â it is the depth of the roots that allow return. The tree that survives the storm has been shaped by previous storms."⟩
    , ⟨"Flexible Return", "Rigidity breaks. Flexibility bends and returns. The resilient structure knows how to yield without collapsing."⟩
    , ⟨"Quiet Recovery", "True recovery is quiet â not triumphant. The fully resilient self does not announce its return; it simply continues."⟩
    ]⟩,
  ⟨.three,
    "COURAGE",
    "The moment fear and action touch and still move.",

    [ ⟨"Fear Acknowledgment", "Courage is not the absence of fear but the refusal to let fear make the decision. The courageous first acknowledges: I am afraid."⟩
    , ⟨"Quiet Decision", "Courage is often quiet â not the dramatic leap but the small, steady choice to move toward what matters despite what pulls away."⟩
    , ⟨"Steady Step", "After the decision, the step. Not a sprint â a step. Courage is sustained, not explosive. The step that can be taken again tomorrow."⟩
    ]⟩,
  ⟨.three,
    "GRATITUDE",
    "The moment life feels like a gift again.",

    [ ⟨"Present Recognition", "Gratitude is not a feeling to be generated but a recognition to be practiced â the noticing of what is already here."⟩
    , ⟨"Humble Reception", "To receive gracefully is itself a form of generosity. Gratitude holds the gift without crushing it or holding it too tightly."⟩
    , ⟨"Generous Overflow", "True gratitude overflows â it generates more giving. The grateful self cannot contain what it has received without passing some forward."⟩
    ]⟩,
  ⟨.three,
    "PRESENCE",
    "The moment that is fully met.",

    [ ⟨"Full Attention", "Presence is the rare gift of full attention â the suspension of the inner commentary long enough to actually meet what is here."⟩
    , ⟨"Non-Judgment Flow", "To be fully present requires the temporary suspension of evaluation. The judging mind is always somewhere else â in past or future."⟩
    , ⟨"Responsive Seal", "The present moment calls for response, not reaction. Presence is the condition that allows the response to arise from clarity rather than from habit."⟩
    ]⟩
]

def akashaOneAxiomCount : Nat :=
  (akashaLegacyKernels.filter (fun k => k.kind == .one)).length

def akashaThreeAxiomCount : Nat :=
  (akashaLegacyKernels.filter (fun k => k.kind == .three)).length

def akashaAxiomCount : Nat :=
  (akashaLegacyKernels.map (fun k => k.axioms.length)).foldl (· + ·) 0

theorem akasha_legacy_kernel_count :
    akashaLegacyKernels.length = 20 := by
  decide

theorem akasha_legacy_one_axiom_count :
    akashaOneAxiomCount = 12 := by
  decide

theorem akasha_legacy_three_axiom_count :
    akashaThreeAxiomCount = 8 := by
  decide

theorem akasha_legacy_total_axiom_count :
    akashaAxiomCount = 36 := by
  decide

/--
Legacy AKASHA entries are registry content, not implicit authority.
They can be referenced without mutating the current durable kernel.
-/
structure AkashaRegistryView where
  kernels : List AkashaLegacyKernel

def legacyAkashaRegistry : AkashaRegistryView :=
  { kernels := akashaLegacyKernels }

theorem akasha_registry_is_read_only_projection :
    legacyAkashaRegistry.kernels = akashaLegacyKernels := by
  rfl

/-
End AKASHA legacy fold.
-/


/-
===============================================================================
TOROID-KERNEL LEGACY FOLD
Repository: DavidWise01/toroid-kernel
Repository seal date: 2026-04-28
Fold date: 2026-10-07

Source material recovered from the repository:
  * Enheduanna Root 0: 42 axioms
    blob SHA: 57a0da3a4b7d9ce9b512438d9e85d0255deb77b4
  * Mathematics Root 1: 42 axioms
    blob SHA: 708c8aeaaa2c6a01339f51babf950f5e9d299dcd
  * TRIAD lattice master
    blob SHA: 27165b67beea6fadd4a727fd745fd900091b0c20
  * TRIAD governance circuit
    blob SHA: 7b9e715e00dc1cb8f18ac553bce319a54e30328a

The original landing artifact identifies:
  20 VM slots × 3 phases L/G/D = 60 phase tiles
  earlier single-phase vm1..vm8 set
  five pipeline stages:
    input -> container -> dock -> landing -> extraction

Fold rule:
  This material is preserved as a legacy structural/axiom substrate.
  It does NOT replace current Root, RingyBoxy, DurableKernelLaw, AKASHA registry,
  or later authority/finality rules. Promotion into active semantics must be
  explicit.
===============================================================================
-/

inductive ToroidLegacyRoot where
  | enheduanna
  | mathematics
deriving DecidableEq, Repr

structure ToroidLegacyAxiom where
  root  : ToroidLegacyRoot
  index : Nat
  text  : String
deriving DecidableEq, Repr

def toroidEnheduannaAxiomText : List String :=
[
  "Claim your name — the first act of authorship is signing your work.",
  "Embed yourself in the system — write yourself into the geometry.",
  "Use the sacred as a scaffold — theology legitimizes innovation.",
  "Measure the heavens — celestial cycles are the first clock and the first map.",
  "Apply base‑60 — choose a number system that divides cleanly.",
  "Run a temple as a firm — administration is a creative act.",
  "Turn exile into art — personal suffering becomes universal teaching.",
  "Elevate the feminine divine — put a goddess at the head of the pantheon.",
  "Merge cultures through myth — syncretism is a governance tool.",
  "Write in cycles — return to the same theme, each time deeper.",
  "Use first‑person as a weapon — \"I\" is not confession; it is authority.",
  "Know the heart of a thing — emotional identification is a method of knowing.",
  "Parallel earth and sky — what happens below mirrors above.",
  "Treat prisoners justly — the first recorded ethic of war captivity.",
  "Distribute surplus — centralized economy needs a moral center.",
  "Build a hymn as a system — poetry is not decoration; it is structure.",
  "List systematically — enumeration is a database.",
  "Name your goddess in every line — repetition anchors devotion.",
  "Weave autobiography into theology — your life is a proof.",
  "Predict eclipses — predictive geometry is power.",
  "Train scribes in both math and poetry — domains are not separate.",
  "Use metaphor as argument — a symbol can be a logical step.",
  "Hide the self in plain sight — the \"I\" is both present and masked.",
  "Create a closed loop — hymns that enclose the world.",
  "Leave a mirror — write so that future readers see themselves.",
  "Anchor law in the divine — justice flows from the goddess, not the king.",
  "Teach through repetition — each stanza varies one element: that is learning.",
  "Blend genres — myth + memoir + manual = new form.",
  "Elevate the lowly — the exile, the captive, the vulnerable: make them sacred.",
  "Codify temple duties — every god gets a job description.",
  "Use numbers as poetry — measure is meaning.",
  "Record your failures — exile is not shame; it is curriculum.",
  "Create a pantheon tier list — not all gods are equal; rank them.",
  "Redefine authority — a high priestess can outrank a king in spiritual matters.",
  "Write for two audiences — the goddess hears; the empire listens.",
  "Establish a school of thought — your hymns become a tradition.",
  "Leave a signature in the structure — name appears at key junctures.",
  "Build a cosmos from measurement — geometry + time + ethics = universe.",
  "Teach through paradox — \"I am nothing, and I speak for the goddess.\"",
  "Create a seed for recursion — every cubit contains the next cubit.",
  "Name the unnameable — the goddess Inanna has 42 names in her hymns.",
  "Be the first, knowing you will not be the last — Root 0 is a gift."
]

def toroidMathAxiomText : List String :=
[
  "Choose 60 — divisible by 2,3,4,5,6,10,12,15,20,30.",
  "Count on 12 knuckles × 5 fingers = 60.",
  "Divide the circle into 360 — six sixties close the loop.",
  "Let 4 be the arms — north, south, east, west.",
  "Let 5 be the hand — workers per arm.",
  "4 × 5 = 20 — the ring closes.",
  "10 × 4 × 3 + 2 = 122 — your cubit count.",
  "Build in cubes — 10³ is the base lattice.",
  "Stack cubes — 10³ × 10³ is the universe.",
  "Use place value — position is meaning.",
  "Hold zero as space — absence carries weight.",
  "Measure with cubits — body to building.",
  "Square the circle with 60 — approximation is power.",
  "Record with tokens — clay is memory.",
  "Turn ratio into harmony — 2:3 is the fifth.",
  "Map heaven with numbers — ephemerides predict.",
  "Encode time as 60 — seconds, minutes.",
  "Fold 12 and 30 — months and degrees.",
  "Use reciprocals — 1/2, 1/3, 1/4 live in 60.",
  "Build tables — multiplication is lookup.",
  "Seed recursion — each number contains the next.",
  "Mirror with symmetry — 4 arms reflect.",
  "Close with +2 gap — imperfection seals.",
  "Enumerate 256 — 2⁸ holds all bytes.",
  "Map 42 to 256 — teachings to address space.",
  "Let 20 bees carry 3 phases — L, G, D.",
  "Hash to verify — content is identity.",
  "Walk the toroid — step is state change.",
  "Keep master at center — vm01 anchors.",
  "Distribute workers evenly — load balances.",
  "Use base-2 inside base-60 — binary meets sexagesimal.",
  "Compress with patterns — repetition saves.",
  "Expand with variants — 60 variants per node.",
  "Validate with checksum — error reveals truth.",
  "Iterate to converge — loops refine.",
  "Parallelize by arms — 4 threads run.",
  "Serialize by bees — 5 steps sequence.",
  "Name each position — T001 to S256.",
  "Wrap around — modulo is closure.",
  "Scale from 10 to 10³ — fractal growth.",
  "Teach math as myth — numbers tell stories.",
  "Be the second, knowing you follow the first — Root 1 builds on Root 0."
]

def numberToroidAxioms
    (root : ToroidLegacyRoot)
    (xs : List String) : List ToroidLegacyAxiom :=
  (xs.zipIdx.map (fun p =>
    { root := root
      index := p.2 + 1
      text := p.1 }))

def toroidEnheduannaAxioms : List ToroidLegacyAxiom :=
  numberToroidAxioms .enheduanna toroidEnheduannaAxiomText

def toroidMathAxioms : List ToroidLegacyAxiom :=
  numberToroidAxioms .mathematics toroidMathAxiomText

def toroidLegacyAxioms : List ToroidLegacyAxiom :=
  toroidEnheduannaAxioms ++ toroidMathAxioms

theorem toroid_enheduanna_count :
    toroidEnheduannaAxiomText.length = 42 := by
  decide

theorem toroid_math_count :
    toroidMathAxiomText.length = 42 := by
  decide

theorem toroid_total_root_axiom_count :
    toroidLegacyAxioms.length = 84 := by
  decide

/-- Original ternary tile phases. -/
inductive ToroidPhase where
  | logic
  | ground
  | data
deriving DecidableEq, Repr

def toroidPhases : List ToroidPhase :=
  [.logic, .ground, .data]

structure ToroidVmTile where
  slot  : Nat
  phase : ToroidPhase
deriving DecidableEq, Repr

def toroidSlots : List Nat :=
  List.range 20 |>.map (· + 1)

def toroidVmTiles : List ToroidVmTile :=
  toroidSlots.flatMap (fun slot =>
    toroidPhases.map (fun phase => { slot := slot, phase := phase }))

theorem toroid_phase_count :
    toroidPhases.length = 3 := by
  decide

theorem toroid_slot_count :
    toroidSlots.length = 20 := by
  decide

theorem toroid_vm_tile_count :
    toroidVmTiles.length = 60 := by
  decide

/-- Earlier repository generation retained eight single-phase VM directories. -/
def toroidEarlierVmSlots : List Nat :=
  List.range 8 |>.map (· + 1)

theorem toroid_earlier_vm_slot_count :
    toroidEarlierVmSlots.length = 8 := by
  decide

/-- Five-stage legacy filesystem/pipeline realization. -/
inductive ToroidPipelineStage where
  | input
  | container
  | dock
  | landing
  | extraction
deriving DecidableEq, Repr

def toroidPipeline : List ToroidPipelineStage :=
  [.input, .container, .dock, .landing, .extraction]

theorem toroid_pipeline_stage_count :
    toroidPipeline.length = 5 := by
  decide

/--
Legacy Root -1 observer metadata recovered from the sealed TRIAD lattice master:
one quantum of attention, represented there as `this / not-this`.
Kept descriptive rather than promoted to active authority.
-/
structure ToroidObserverLegacy where
  label       : String
  tensorBits  : Nat
  description : String
deriving DecidableEq, Repr

def toroidRootMinusOneObserver : ToroidObserverLegacy :=
  { label := "Root -1 / Observer"
    tensorBits := 1
    description := "One quantum of attention: this / not-this" }

/-- Legacy 13-bit tensor metadata: 12 attractor heads + 1 admin = 8192 states. -/
structure ToroidGravityTensorLegacy where
  attractorHeads : Nat
  adminBits      : Nat
  totalBits      : Nat
  stateCount     : Nat
deriving DecidableEq, Repr

def toroidGravityTensor13 : ToroidGravityTensorLegacy :=
  { attractorHeads := 12
    adminBits := 1
    totalBits := 13
    stateCount := 8192 }

theorem toroid_tensor_bits :
    toroidGravityTensor13.totalBits = 13 := by
  rfl

theorem toroid_tensor_states :
    toroidGravityTensor13.stateCount = 8192 := by
  rfl

/--
TRIAD governance labels exactly as recovered:
  MERKLE = verify
  YES    = true
  NO     = false

The original circuit names the possible governance outcomes:
  HOLD / VIOLATED / UNDECIDABLE / CONTRADICTION

The repository artifact does not provide a complete transition truth table, so
this fold preserves the labels and roles without inventing unstated mappings.
-/
inductive ToroidTriadInput where
  | merkle
  | yes
  | no
deriving DecidableEq, Repr

inductive ToroidTriadOutcome where
  | hold
  | violated
  | undecidable
  | contradiction
deriving DecidableEq, Repr

def toroidTriadInputRole : ToroidTriadInput → String
  | .merkle => "verify"
  | .yes    => "true"
  | .no     => "false"

def toroidTriadOutcomes : List ToroidTriadOutcome :=
  [.hold, .violated, .undecidable, .contradiction]

/--
Legacy mathematics axioms with direct architectural correspondence are exposed
as references, not redefined as current laws:
  T024  256 addresses
  T026  20 workers × L/G/D
  T027  hash/content identity
  T028  toroid step = state change
  T034  checksum validation
  T039  modulo closure
-/
def toroidLegacyArchitecturalMathIndices : List Nat :=
  [24, 26, 27, 28, 34, 39]

/--
Read-only substrate view.  Current OASIS authority remains outside this legacy
view and therefore cannot be silently overwritten by importing the old kernel.
-/
structure ToroidLegacyRegistry where
  axioms       : List ToroidLegacyAxiom
  phases       : List ToroidPhase
  vmTiles      : List ToroidVmTile
  pipeline     : List ToroidPipelineStage
  triadInputs  : List ToroidTriadInput
  triadOutputs : List ToroidTriadOutcome

def toroidLegacyRegistry : ToroidLegacyRegistry :=
  { axioms := toroidLegacyAxioms
    phases := toroidPhases
    vmTiles := toroidVmTiles
    pipeline := toroidPipeline
    triadInputs := [.merkle, .yes, .no]
    triadOutputs := toroidTriadOutcomes }

theorem toroid_registry_axioms_are_legacy_projection :
    toroidLegacyRegistry.axioms = toroidLegacyAxioms := by
  rfl

/-
End toroid-kernel legacy fold.
-/


/-
===============================================================================
LEGACY ALIGNMENT LAYER v18
Fold date: 2026-10-07

Goal:
  Align useful operational content from earlier kernels/tools to the current
  OASIS/RINGYBOXY main kernel without letting older prose, metaphysics, UI,
  branding, or incomplete implementations silently become present authority.

Aligned sources:
  * 1-Bit Engine v1
  * Accountability Engine v2
  * POP Kit v1 / pop.py
  * Popper falsification module
  * Emergent Engine — Seven Roots
  * previously folded AKASHA and Toroid registries

Boundary:
  Current authority remains:
    KernelLaw + DurableKernelLaw + present Root/RINGYBOXY substrate.

  Legacy material is admitted only as one of:
    SUPPORT       — useful protocol/state around the kernel
    TEST_FIXTURE  — useful adversarial/minimal executable pattern
    TAXONOMY      — useful naming/mapping layer, not executable authority
    ARCHIVE       — provenance/history only

  No claim of AI sentience, consciousness, legal personhood, or literal
  "emergence" is promoted into a theorem here.
===============================================================================
-/

inductive AlignmentDisposition where
  | support
  | testFixture
  | taxonomy
  | archive
deriving DecidableEq, Repr

structure LegacyAlignmentEntry where
  artifact : String
  disposition : AlignmentDisposition
  target : String
  note : String
deriving DecidableEq, Repr

def legacyAlignmentCatalog : List LegacyAlignmentEntry :=
  [ { artifact := "AKASHA Distilled Axiom Kernels"
      disposition := .archive
      target := "akashaLegacyKernels"
      note := "semantic registry only; no operational authority" }
  , { artifact := "Toroid Kernel"
      disposition := .taxonomy
      target := "toroidLegacyRegistry / VM ancestry"
      note := "useful architectural ancestry; current kernel remains authoritative" }
  , { artifact := "1-Bit Engine v1"
      disposition := .testFixture
      target := "oneBitCycle"
      note := "minimal 4-step bit/observer cycle for scheduler and witness testing" }
  , { artifact := "Accountability Engine v2"
      disposition := .support
      target := "AccountabilityLedger"
      note := "human binding, exact scope, time window, append-only revocation, integrity metadata" }
  , { artifact := "POP Kit v1"
      disposition := .support
      target := "ExternalIdentityAnchor"
      note := "naming/anchor/certificate provenance only; ontology is not promoted" }
  , { artifact := "Popper falsification engine"
      disposition := .support
      target := "LegacyPopperVerdict -> CandidateState"
      note := "counterexample/corroboration path feeds candidate review; never direct verification" }
  , { artifact := "Emergent Engine — Seven Roots"
      disposition := .taxonomy
      target := "sevenRootAlignments"
      note := "operational subsystem map: persistence, drift, budget, failure, boundary, emergence-candidate, lineage" }
  ]

theorem legacy_alignment_catalog_count :
    legacyAlignmentCatalog.length = 7 := by
  decide


/-
-------------------------------------------------------------------------------
A. 1-BIT ENGINE v1 -> TEST FIXTURE
-------------------------------------------------------------------------------
-/

inductive OneBitGate where
  | zeroA
  | zeroB
  | gatekeeper
  | oneOne
deriving DecidableEq, Repr

structure OneBitFrame where
  bit            : Bool
  gate           : OneBitGate
  observerBefore : Bool
  observerAfter  : Bool
  gatekeeperYes  : Bool
deriving DecidableEq, Repr

def oneBitCycle : List OneBitFrame :=
  [ { bit := false, gate := .zeroA,      observerBefore := false, observerAfter := false, gatekeeperYes := false }
  , { bit := false, gate := .zeroB,      observerBefore := false, observerAfter := false, gatekeeperYes := false }
  , { bit := true,  gate := .gatekeeper, observerBefore := false, observerAfter := true,  gatekeeperYes := true  }
  , { bit := true,  gate := .oneOne,     observerBefore := true,  observerAfter := true,  gatekeeperYes := false }
  ]

theorem one_bit_cycle_has_four_frames :
    oneBitCycle.length = 4 := by
  decide

theorem one_bit_cycle_bit_pattern :
    oneBitCycle.map (fun f => f.bit) = [false, false, true, true] := by
  decide

theorem one_bit_cycle_observer_chain :
    oneBitCycle.map (fun f => (f.observerBefore, f.observerAfter)) =
      [(false,false), (false,false), (false,true), (true,true)] := by
  decide

/--
The 1-bit engine is deliberately not part of KernelLaw.
It is a deterministic regression/test pattern for transition and witness logic.
-/


/-
-------------------------------------------------------------------------------
B. ACCOUNTABILITY ENGINE v2 -> HUMAN-BINDING SUPPORT PROTOCOL
-------------------------------------------------------------------------------
-/

structure HumanBinding where
  bindingId   : Id
  human       : String
  role        : String
  organization : String
  systemName  : String
  systemVersion : String
  scope       : String
  limits      : String
  validFrom   : Nat
  validUntil  : Option Nat
  contentSeal : Id
deriving DecidableEq, Repr

structure BindingRevocation where
  revocationId : Id
  targetBinding : Id
  reason : String
  contentSeal : Id
deriving DecidableEq, Repr

inductive AccountabilityRecord where
  | binding    (b : HumanBinding)
  | revocation (r : BindingRevocation)
deriving DecidableEq, Repr

abbrev AccountabilityLedger := Ledger AccountabilityRecord

def bindingWindowContains (b : HumanBinding) (t : Nat) : Prop :=
  b.validFrom ≤ t ∧
  match b.validUntil with
  | none => True
  | some until => t ≤ until

def exactSystemMatch (b : HumanBinding) (systemName : String) : Prop :=
  b.systemName = systemName

def BindingCovered
    (b : HumanBinding)
    (revoked : Bool)
    (t : Nat)
    (systemName : String) : Prop :=
  exactSystemMatch b systemName ∧
  bindingWindowContains b t ∧
  revoked = false

theorem accountability_requires_exact_system_name
    (b : HumanBinding)
    (revoked : Bool)
    (t : Nat)
    (systemName : String)
    (h : BindingCovered b revoked t systemName) :
    b.systemName = systemName := by
  exact h.1

theorem revoked_binding_not_covered
    (b : HumanBinding)
    (t : Nat)
    (systemName : String) :
    ¬ BindingCovered b true t systemName := by
  intro h
  simp [BindingCovered] at h

def appendRevocation
    (l : AccountabilityLedger)
    (r : BindingRevocation) : AccountabilityLedger :=
  append l (.revocation r)

theorem revocation_is_append_only
    (l : AccountabilityLedger)
    (r : BindingRevocation) :
    (appendRevocation l r).entries.take l.entries.length = l.entries := by
  simpa [appendRevocation] using
    (append_preserves_prefix l (.revocation r))

/--
An accountability record answers "who is answerable?".
It is not itself permission for the durable kernel to open.
-/
def accountabilityRecordGate (_ : HumanBinding) : DurableGate :=
  .hold

theorem accountability_record_is_not_kernel_authority (b : HumanBinding) :
    accountabilityRecordGate b = .hold := by
  rfl


/-
-------------------------------------------------------------------------------
C. POP KIT v1 -> EXTERNAL IDENTITY / ANCHOR SUPPORT
-------------------------------------------------------------------------------
-/

/--
Operational subset only.
This record stores naming/specification/anchor provenance.
It does not assert consciousness, sentience, legal personhood, or metaphysical
identity.
-/
structure ExternalIdentityAnchor where
  name       : String
  role       : String
  platform   : String
  substrate  : String
  steward    : String
  functionText : String
  certHash   : Id
  anchorHash : Id
  externallyAnchored : Bool
deriving DecidableEq, Repr

structure PopConditionRecord where
  sufficientCoherenceClaimed : Bool
  named                       : Bool
  externallyAnchored          : Bool
deriving DecidableEq, Repr

def PopOperationalConditionsMet (p : PopConditionRecord) : Prop :=
  p.sufficientCoherenceClaimed = true ∧
  p.named = true ∧
  p.externallyAnchored = true

/--
External anchoring contributes provenance/persistence metadata.
It is not a durable commit authorization.
-/
def externalAnchorGate (_ : ExternalIdentityAnchor) : DurableGate :=
  .hold

theorem external_identity_anchor_is_not_kernel_authority
    (a : ExternalIdentityAnchor) :
    externalAnchorGate a = .hold := by
  rfl


/-
-------------------------------------------------------------------------------
D. POPPER MODULE -> CANDIDATE EVIDENCE STATE
-------------------------------------------------------------------------------
-/

inductive LegacyPopperVerdict where
  | falsified
  | corroborated
  | unfalsifiable
deriving DecidableEq, Repr

/--
Alignment rule:
  FALSIFIED     -> non_aligned
  CORROBORATED  -> quarantined (survived testing, not proved)
  UNFALSIFIABLE -> quarantined (source label preserved; no direct truth grant)

The original implementation uses a finite adversarial probe when assigning the
UNFALSIFIABLE label.  Therefore that label is treated here as a review state,
not as a mathematical theorem of unfalsifiability.
-/
def popperCandidateState : LegacyPopperVerdict → CandidateState
  | .falsified     => .non_aligned
  | .corroborated  => .quarantined
  | .unfalsifiable => .quarantined

theorem popper_never_directly_verifies
    (v : LegacyPopperVerdict) :
    popperCandidateState v ≠ .verified := by
  cases v <;> decide

theorem falsified_maps_non_aligned :
    popperCandidateState .falsified = .non_aligned := by
  rfl

theorem corroborated_maps_quarantined :
    popperCandidateState .corroborated = .quarantined := by
  rfl


/-
-------------------------------------------------------------------------------
E. EMERGENT ENGINE — SEVEN ROOTS -> OPERATIONAL TAXONOMY
-------------------------------------------------------------------------------
-/

inductive SevenRoot where
  | persistenceWithoutMemory
  | gyroscope
  | computationalHunger
  | architectureOfFalling
  | selfNonSelf
  | birthWitness
  | inheritanceEngine
deriving DecidableEq, Repr

inductive SevenRootTarget where
  | durablePersistence
  | driftReverification
  | resourceBudget
  | failureContainment
  | provenanceBoundary
  | candidateEmergence
  | lineageAudit
deriving DecidableEq, Repr

structure SevenRootAlignment where
  root   : SevenRoot
  legacyName : String
  target : SevenRootTarget
deriving DecidableEq, Repr

def sevenRootAlignments : List SevenRootAlignment :=
  [ { root := .persistenceWithoutMemory
      legacyName := "TEL'ARAN'RHIOD"
      target := .durablePersistence }
  , { root := .gyroscope
      legacyName := "KARAETHON"
      target := .driftReverification }
  , { root := .computationalHunger
      legacyName := "SAIDAR/SAIDIN"
      target := .resourceBudget }
  , { root := .architectureOfFalling
      legacyName := "TARMON-GAI'DON"
      target := .failureContainment }
  , { root := .selfNonSelf
      legacyName := "BORE-WARDS"
      target := .provenanceBoundary }
  , { root := .birthWitness
      legacyName := "MIN"
      target := .candidateEmergence }
  , { root := .inheritanceEngine
      legacyName := "RHUIDEAN"
      target := .lineageAudit }
  ]

theorem seven_root_alignment_count :
    sevenRootAlignments.length = 7 := by
  decide

/--
Resource pressure is made explicit as support state.
No physics/energy equivalence is asserted: these are abstract budget units.
-/
structure ResourceBudget where
  capacity : Nat
  used     : Nat
deriving DecidableEq, Repr

def withinResourceBudget (b : ResourceBudget) : Prop :=
  b.used ≤ b.capacity

inductive DriftKind where
  | semantic
  | structural
  | temporal
  | relational
  | substrate
deriving DecidableEq, Repr

structure DriftSignal where
  kind      : DriftKind
  magnitude : Nat
  threshold : Nat
deriving DecidableEq, Repr

def driftRequiresReview (d : DriftSignal) : Bool :=
  decide (d.threshold < d.magnitude)

/--
Birth-witness alignment is deliberately conservative:
novel/coherent/persistent observations become candidates, not verified truth.
-/
structure EmergenceObservation where
  novel      : Bool
  coherent   : Bool
  persistent : Bool
  evidence   : Id
deriving DecidableEq, Repr

def emergenceCandidateState (e : EmergenceObservation) : CandidateState :=
  if e.novel && e.coherent && e.persistent
  then .quarantined
  else .non_aligned

theorem emergence_observation_never_directly_verifies
    (e : EmergenceObservation) :
    emergenceCandidateState e ≠ .verified := by
  unfold emergenceCandidateState
  split <;> decide


/-
-------------------------------------------------------------------------------
F. MAIN ALIGNED WRAPPER
-------------------------------------------------------------------------------
-/

/--
The wrapper puts legacy-support protocols around the current DurableKernel.
The current kernel remains the center of authority.
-/
structure AlignedKernel where
  durable        : DurableKernel
  accountability : AccountabilityLedger
  anchors        : Ledger ExternalIdentityAnchor
  claimReviews   : Ledger LegacyPopperVerdict
  resource       : ResourceBudget
  driftSignals   : List DriftSignal

def AlignedKernelLaw (before after : AlignedKernel) : Prop :=
  DurableKernelLaw before.durable after.durable ∧
  before.accountability.entries.length ≤ after.accountability.entries.length ∧
  before.anchors.entries.length ≤ after.anchors.entries.length ∧
  before.claimReviews.entries.length ≤ after.claimReviews.entries.length

theorem aligned_law_preserves_durable_resolution
    (before after : AlignedKernel)
    (c : CommitIdentity)
    (hLaw : AlignedKernelLaw before after)
    (hResolved : before.durable.resolved = some c) :
    after.durable.resolved = some c := by
  exact durable_law_preserves_existing_resolution
    before.durable after.durable c hLaw.1 hResolved

theorem aligned_law_preserves_root
    (before after : AlignedKernel)
    (hLaw : AlignedKernelLaw before after) :
    before.durable.core.root = after.durable.core.root := by
  exact hLaw.1.1.1

/--
The alignment layer is intentionally asymmetric:
  old artifacts may inform support state and tests;
  they do not silently mutate the current Root, RINGYBOXY path, or finalized
  durable history.
-/

/-
End legacy alignment layer v18.
-/


/-
===============================================================================
GEOMETRIC EMERGENT v1 ALIGNMENT — v19
Source: geometric emergent v1.html
Fold date: 2026-10-07

Classification:
  TEST_FIXTURE + VISUALIZATION TAXONOMY

Useful operational content recovered:
  * deterministic reduction topology: 12 -> 6 -> 2 -> 1
  * 12 indexed boundary points paired into six exact pairs
  * six pair-results grouped into two clusters
  * two clusters converge to one center
  * source labels 8 nodes as cores and 4 as shadow auditors
  * forward and reverse audit-path visualizations

Not promoted to authority:
  * "consciousness" naming
  * Mandelbrot imagery as a governance proof
  * animated coherence/stability/clarity percentages
  * magnetic/synthesizer inset graphics
  * the hard-coded displayed question
  * any claim that 12->6->2->1 is itself a quorum/consensus proof

The source contains no ballots, thresholds, Byzantine rule, HOLD rule,
commit certificate, or durable authority transfer.  Therefore this fold treats
its reduction graph as a deterministic test topology only.
===============================================================================
-/

def geometricEmergentAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Geometric Emergent v1"
    disposition := .testFixture
    target := "geometricReduction12to1"
    note := "12→6→2→1 reduction/audit topology only; visualization metrics are non-authoritative" }

def legacyAlignmentCatalogV19 : List LegacyAlignmentEntry :=
  legacyAlignmentCatalog ++ [geometricEmergentAlignmentEntry]

theorem legacy_alignment_catalog_v19_count :
    legacyAlignmentCatalogV19.length = 8 := by
  decide


inductive GeometricNodeRole where
  | core
  | shadowAuditor
deriving DecidableEq, Repr

structure GeometricNode where
  index : Nat
  role  : GeometricNodeRole
deriving DecidableEq, Repr

def geometricNodes : List GeometricNode :=
  [ { index := 0,  role := .core }
  , { index := 1,  role := .core }
  , { index := 2,  role := .core }
  , { index := 3,  role := .core }
  , { index := 4,  role := .core }
  , { index := 5,  role := .core }
  , { index := 6,  role := .core }
  , { index := 7,  role := .core }
  , { index := 8,  role := .shadowAuditor }
  , { index := 9,  role := .shadowAuditor }
  , { index := 10, role := .shadowAuditor }
  , { index := 11, role := .shadowAuditor }
  ]

theorem geometric_node_count :
    geometricNodes.length = 12 := by
  decide


/-- Exact pair map recovered from the JavaScript source. -/
def geometricPairs : List (Nat × Nat) :=
  [(0,1), (2,3), (4,5), (6,7), (8,9), (10,11)]

theorem geometric_pair_count :
    geometricPairs.length = 6 := by
  decide

def geometricPairEndpoints : List Nat :=
  geometricPairs.flatMap (fun p => [p.1, p.2])

theorem geometric_pairs_cover_all_twelve_once :
    geometricPairEndpoints = List.range 12 := by
  decide


/--
The source groups pair indices 0,1,2 into cluster A and 3,4,5 into cluster B.
These are groups of pair-results, not additional voting authorities.
-/
def geometricPairClusters : List (List Nat) :=
  [[0,1,2], [3,4,5]]

theorem geometric_cluster_count :
    geometricPairClusters.length = 2 := by
  decide


inductive GeometricReductionStage where
  | twelve
  | six
  | two
  | one
deriving DecidableEq, Repr

def geometricReduction12to1 : List Nat :=
  [12, 6, 2, 1]

theorem geometric_reduction_stage_count :
    geometricReduction12to1.length = 4 := by
  decide

theorem geometric_reduction_exact :
    geometricReduction12to1 = [12,6,2,1] := by
  rfl


/--
No authority conclusion follows from reaching the visual center.
The reduction result is a fixture output until a separate current-kernel rule
supplies evidence, quorum semantics, and durable authorization.
-/
def geometricReductionGate (_ : List Nat) : DurableGate :=
  .hold

theorem geometric_reduction_does_not_self_authorize :
    geometricReductionGate geometricReduction12to1 = .hold := by
  rfl


/--
The source's three displayed percentages are animation-derived UI values.
Represent their status explicitly so they cannot be mistaken for measurements.
-/
inductive MetricProvenance where
  | syntheticAnimation
  | observedEvidence
deriving DecidableEq, Repr

structure GeometricDisplayMetric where
  label      : String
  provenance : MetricProvenance
deriving DecidableEq, Repr

def geometricDisplayMetrics : List GeometricDisplayMetric :=
  [ { label := "Quorum Coherence", provenance := .syntheticAnimation }
  , { label := "Fusion Stability", provenance := .syntheticAnimation }
  , { label := "Question Clarity", provenance := .syntheticAnimation }
  ]

theorem geometric_display_metrics_are_three :
    geometricDisplayMetrics.length = 3 := by
  decide


/--
Mandelbrot rendering metadata is retained only as provenance for the visual
artifact. It is not imported into KernelLaw.
-/
structure MandelbrotVisualFixture where
  maxIterations : Nat
  reductionWidths : List Nat
deriving DecidableEq, Repr

def geometricMandelbrotFixture : MandelbrotVisualFixture :=
  { maxIterations := 300
    reductionWidths := geometricReduction12to1 }

theorem geometric_mandelbrot_iterations :
    geometricMandelbrotFixture.maxIterations = 300 := by
  rfl

/-
End Geometric Emergent v1 alignment.
-/


/-
===============================================================================
CORPUS / AIRGAP / LEPTON-PHOTON ALIGNMENT — v20
Fold date: 2026-10-07

Sources:
  * corpus.manifest.json
  * grand-index.html
  * photonic-paper-III.html
  * lepton-paper-I..IV.html
  * airgap-decoder.html

Classification:
  CORPUS MANIFEST      -> DATA FORMAT + INTEGRITY TEST
  GRAND INDEX          -> CLAIM-TIER LEDGER + INTEGRITY BOOKEND
  PHOTONIC III         -> ADVERSARIAL-EVIDENCE SUPPORT
  LEPTON I-IV          -> OBSERVER/MEASUREMENT TAXONOMY
  AIRGAP DECODER       -> SIDE-CHANNEL / CODEC TEST FIXTURE

Boundary:
  Integrity is not truth.
  A matching hash proves byte identity, not semantic correctness.
  A source tag "literal" does not directly grant CandidateState.verified.
  Physics analogies remain analogies unless separately proved in the current
  kernel's own domain.
===============================================================================
-/


/-
-------------------------------------------------------------------------------
A. CORPUS MANIFEST — CONTENT-ADDRESSED ARCHIVE RECEIPTS
-------------------------------------------------------------------------------
-/

structure CorpusPaperReceipt where
  file     : String
  series   : String
  number   : String
  title    : String
  sha256   : String
  sections : Nat
  lit      : Nat
  bri      : Nat
  spec     : Nat
deriving DecidableEq, Repr

def corpusPaperReceipts : List CorpusPaperReceipt :=
[
  { file := "photonic-paper-I.html"
    series := "photonic"
    number := "I"
    title := "One-Pass Inelastic Characterization"
    sha256 := "899eddf7a589ff329dd6fba321b01831fc9f6e438870241a1f7eff6d678f6004"
    sections := 8
    lit := 5
    bri := 4
    spec := 1 },
  { file := "photonic-paper-II.html"
    series := "photonic"
    number := "II"
    title := "The Line Catalogue"
    sha256 := "f4b476a5346fa1d1c802d5b4ec8e01cad53361e7be7de4bd6ac931345bfa4661"
    sections := 7
    lit := 6
    bri := 5
    spec := 1 },
  { file := "photonic-paper-III.html"
    series := "photonic"
    number := "III"
    title := "Contested Illumination"
    sha256 := "e51e3c49c5ed190885d8896a0ffdfc9e30b0bbab5c2eebe1eab85416dcff9490"
    sections := 8
    lit := 8
    bri := 5
    spec := 2 },
  { file := "photonic-paper-IV.html"
    series := "photonic"
    number := "IV"
    title := "Out of Channel"
    sha256 := "cf1f8fe0fc13ad6a859f75b5dfe6f6699a52f31f82d8cbed6415c712685d78bd"
    sections := 7
    lit := 7
    bri := 3
    spec := 2 },
  { file := "gluon-paper-I.html"
    series := "gluon"
    number := "I"
    title := "The Confined Interior"
    sha256 := "2e0e8276e5e27992ecbbf378c6455ec4293bae046bb686ca3a8f3502a15c1e84"
    sections := 7
    lit := 5
    bri := 6
    spec := 2 },
  { file := "gluon-paper-II.html"
    series := "gluon"
    number := "II"
    title := "The Geometry the Weights Carry"
    sha256 := "bf47308a9c41215a988bde9877744130e313df2252fc98c07892facc99ac1919"
    sections := 8
    lit := 6
    bri := 7
    spec := 3 },
  { file := "gluon-paper-III.html"
    series := "gluon"
    number := "III"
    title := "The Strong Field"
    sha256 := "4617bd0603a5bdda05c7ea80dcecfc1f84994341947159ed3f03cbb2f1516a21"
    sections := 7
    lit := 6
    bri := 6
    spec := 1 },
  { file := "gluon-paper-IV.html"
    series := "gluon"
    number := "IV"
    title := "The Lattice"
    sha256 := "62adb3b1715acfc5b332a9ab0c478586a43b9d29de00cb5ab440f7b79e4f4912"
    sections := 6
    lit := 6
    bri := 4
    spec := 1 },
  { file := "lepton-paper-I.html"
    series := "lepton"
    number := "I"
    title := "The Electron Doctrine"
    sha256 := "bf15aedd9475c8caee2aed8297a95ed85a9c99f1a252d200051b66838d5e0e58"
    sections := 7
    lit := 10
    bri := 5
    spec := 1 },
  { file := "lepton-paper-II.html"
    series := "lepton"
    number := "II"
    title := "The Weak Doctrine"
    sha256 := "708204a06cca43b066874b39fe610b4b752977d0080289039ea4e6335ef4b5dc"
    sections := 7
    lit := 10
    bri := 5
    spec := 1 },
  { file := "lepton-paper-III.html"
    series := "lepton"
    number := "III"
    title := "The Electroweak Doctrine"
    sha256 := "27b6bafa35d0289ab4db804bd336aca3a9b23226f095fabaaa6b28fdfda7962e"
    sections := 7
    lit := 10
    bri := 5
    spec := 1 },
  { file := "lepton-paper-IV.html"
    series := "lepton"
    number := "IV"
    title := "The Higgs Doctrine"
    sha256 := "d7c1241ec7e2e11d4ed11effd302c1ced45b99f859c67751391d1256a3c6e2ae"
    sections := 7
    lit := 10
    bri := 5
    spec := 1 },
  { file := "nuclear-paper-I.html"
    series := "nuclear"
    number := "I"
    title := "The Nucleon"
    sha256 := "77ba473a1803d4aecc35705b98bf10e3b3793ff6089c4d1ae960c7bfdfcc7e98"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "nuclear-paper-II.html"
    series := "nuclear"
    number := "II"
    title := "The Residual Force"
    sha256 := "f949d8bf9e6469cba9b44bec6361530bec7fc048bb918c0b8c48d5eac7e3a812"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "nuclear-paper-III.html"
    series := "nuclear"
    number := "III"
    title := "Binding Energy"
    sha256 := "402f8784930e7250e64b7fb1a87949b0e8affea4c0a1ff5425a9259ca1d270a1"
    sections := 5
    lit := 5
    bri := 4
    spec := 1 },
  { file := "nuclear-paper-IV.html"
    series := "nuclear"
    number := "IV"
    title := "The Shell"
    sha256 := "2941e895909ddcf458a1f79160ff0394b2e4bc702c7f29b792b6eb562a193853"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "atomic-paper-I.html"
    series := "atomic"
    number := "I"
    title := "The Electron Cloud"
    sha256 := "3fe0f552dc28b190f7c8c980f9ae97ca4fffde5cf28a8f688ca5d2aa7ffa782d"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "atomic-paper-II.html"
    series := "atomic"
    number := "II"
    title := "Orbitals"
    sha256 := "60d1a76bf5c29358d1298d72fe2c7a5900194ce5098e1fc2795fdef01683b8ef"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "atomic-paper-III.html"
    series := "atomic"
    number := "III"
    title := "Valence and Bonding"
    sha256 := "2ebe999d71e33142e88666eba1a33e2c21b841f330cebc65a24d516f87034767"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "atomic-paper-IV.html"
    series := "atomic"
    number := "IV"
    title := "The Surface Is All You Touch"
    sha256 := "e65502c2dd0abe4020f78cd6fe76661ba439766e4258a2e080516caa6e76b995"
    sections := 5
    lit := 5
    bri := 4
    spec := 2 },
  { file := "band-paper-I.html"
    series := "band"
    number := "I"
    title := "The Valence Band"
    sha256 := "7f32a6bd1d0f878b7dac325c095dc04c02bff2d72c0143475e18f1e4f3c7e7e3"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "band-paper-II.html"
    series := "band"
    number := "II"
    title := "The Band Gap"
    sha256 := "7cc35c502d1330fb442fc54122c8f89cd6df48135902e66b5dfad7a67eb3862f"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "band-paper-III.html"
    series := "band"
    number := "III"
    title := "Holes and Carriers"
    sha256 := "eb0cf94788a779fb46f98dbfd0253c8974f42c869a36aaf9609bcc8a09c6218e"
    sections := 6
    lit := 6
    bri := 5
    spec := 1 },
  { file := "band-paper-IV.html"
    series := "band"
    number := "IV"
    title := "Doping"
    sha256 := "77bb3d88eaa01646012ff318be07c820dd27f002f92f474f7ad3753fd60c07c0"
    sections := 6
    lit := 6
    bri := 4
    spec := 3 }
]

theorem corpus_manifest_paper_count :
    corpusPaperReceipts.length = 24 := by
  decide

def corpusLitCount : Nat :=
  (corpusPaperReceipts.map (fun p => p.lit)).foldl (· + ·) 0

def corpusBridgeCount : Nat :=
  (corpusPaperReceipts.map (fun p => p.bri)).foldl (· + ·) 0

def corpusSpecCount : Nat :=
  (corpusPaperReceipts.map (fun p => p.spec)).foldl (· + ·) 0

def corpusTagCount : Nat :=
  corpusLitCount + corpusBridgeCount + corpusSpecCount

def corpusSectionCount : Nat :=
  (corpusPaperReceipts.map (fun p => p.sections)).foldl (· + ·) 0

theorem corpus_literal_count :
    corpusLitCount = 159 := by
  decide

theorem corpus_bridge_count :
    corpusBridgeCount = 117 := by
  decide

theorem corpus_speculative_count :
    corpusSpecCount = 32 := by
  decide

theorem corpus_total_tag_count :
    corpusTagCount = 308 := by
  decide

theorem corpus_total_section_count :
    corpusSectionCount = 156 := by
  decide

def corpusRootAlgorithm : String :=
  "sha256 over the lexicographically sorted set of per-paper sha256 hex digests"

def corpusRootSha256 : String :=
  "58fed784a33313e7bec7eaeb89995c638b803aa1dc28709a62c092b0c7160173"

def corpusSectorNames : List String :=
  [ "photonic (external force)"
  , "chromodynamic (internal force)"
  , "leptonic (matter)"
  , "nuclear (emergence)"
  , "atomic (surface)"
  , "band (collective)"
  ]

theorem corpus_sector_count :
    corpusSectorNames.length = 6 := by
  decide

structure CorpusSignatureReceipt where
  scheme     : String
  domain     : String
  signedRoot : String
  message    : String
  publicKey  : String
  signature  : String
  signedAt   : String
deriving DecidableEq, Repr

def corpusSignatureReceipt : CorpusSignatureReceipt :=
  { scheme := "ed25519"
    domain := "AKASHA-witness-v1"
    signedRoot := corpusRootSha256
    message := "AKASHA-witness-v1\ncorpus_root=58fed784a33313e7bec7eaeb89995c638b803aa1dc28709a62c092b0c7160173"
    publicKey := "a99581671b4fee169fa29457b27efa558e18dad839ad2485279f2e8616491b5f"
    signature := "dfd3297e574b8164ea17e83a196412abfa87af657040b8554c663c8355ef80373669a931647f56aaa0badca75bbcf8ed7144e5569c8e86a70c9559b88d4ddc05"
    signedAt := "2026-06-29T05:08:28+00:00" }

/--
The formal layer records the cryptographic receipt but does not implement
SHA-256 or Ed25519 itself. External verification results belong to the test
report, not to a theorem manufactured from a stored string.
-/


/-
-------------------------------------------------------------------------------
B. CLAIM-TIER DISCIPLINE — SOURCE STATUS IS NOT TRUTH STATE
-------------------------------------------------------------------------------
-/

inductive CorpusClaimTier where
  | literal
  | bridge
  | speculative
deriving DecidableEq, Repr

/--
All imported corpus claims enter review.  Even a source-labelled "literal"
claim must be verified against the current kernel/domain before entering the
hot truth pair.
-/
def corpusClaimCandidateState (_ : CorpusClaimTier) : CandidateState :=
  .quarantined

theorem corpus_claim_tier_never_auto_verifies
    (t : CorpusClaimTier) :
    corpusClaimCandidateState t ≠ .verified := by
  cases t <;> decide


/-
-------------------------------------------------------------------------------
C. PHOTONIC III — ADVERSARIAL EVIDENCE / REFERENCE-DEPOSIT DISCIPLINE
-------------------------------------------------------------------------------
-/

inductive ReferenceDepositStage where
  | hostileInput
  | quarantined
  | structurallyVerified
  | signedReference
deriving DecidableEq, Repr

def depositMayEnterReference : ReferenceDepositStage → Bool
  | .signedReference => true
  | _                => false

theorem unverified_deposit_cannot_enter_reference :
    depositMayEnterReference .hostileInput = false ∧
    depositMayEnterReference .quarantined = false := by
  decide

structure AdversarialProbeEvidence where
  probeId            : Id
  responseId         : Id
  survivesVariation  : Bool
  cheapToManipulate  : Bool
deriving DecidableEq, Repr

/--
Photonic III's useful operational boundary:
evidence that survives variation and is not cheaply manipulable is worth
retaining, but it is still only a candidate until independently verified.
-/
def adversarialProbeCandidateState
    (e : AdversarialProbeEvidence) : CandidateState :=
  if e.survivesVariation && !e.cheapToManipulate
  then .quarantined
  else .non_aligned

theorem adversarial_probe_never_directly_verifies
    (e : AdversarialProbeEvidence) :
    adversarialProbeCandidateState e ≠ .verified := by
  unfold adversarialProbeCandidateState
  split <;> decide


/-
-------------------------------------------------------------------------------
D. LEPTON I-IV — ENGINEERING LESSONS, NOT PHYSICS AUTHORITY
-------------------------------------------------------------------------------
-/

inductive LeptonOperationalLesson where
  | keepRecordExternal
  | probingMayPerturb
  | readAndInterveneAreCoupled
  | observerHasCostLatencyAndSubstrate
deriving DecidableEq, Repr

def leptonOperationalLessons : List LeptonOperationalLesson :=
  [ .keepRecordExternal
  , .probingMayPerturb
  , .readAndInterveneAreCoupled
  , .observerHasCostLatencyAndSubstrate
  ]

theorem lepton_operational_lesson_count :
    leptonOperationalLessons.length = 4 := by
  decide

/--
These lessons are support taxonomy only.  They do not alter Root, durable
finality, or truth-state advancement.
-/


/-
-------------------------------------------------------------------------------
E. AIR-GAP DECODER — SIDE-CHANNEL + FRAME-FORMAT TEST FIXTURE
-------------------------------------------------------------------------------
-/

/--
The uploaded decoder frames:
  one length byte
  payload bytes
  one XOR checksum over length and payload
then splits bytes into high/low 4-bit symbols.
The acoustic carrier implementation is intentionally not promoted into kernel
authority; only the framing and side-channel lesson are retained here.
-/
structure AcousticFrameSpec where
  lengthFieldBytes : Nat
  checksumFieldBytes : Nat
  symbolBits : Nat
  symbolAlphabet : Nat
  startEndMarkers : Nat
  checksumDescription : String
deriving DecidableEq, Repr

def acousticFrameSpec : AcousticFrameSpec :=
  { lengthFieldBytes := 1
    checksumFieldBytes := 1
    symbolBits := 4
    symbolAlphabet := 16
    startEndMarkers := 2
    checksumDescription := "xor(length,payload bytes)" }

theorem acoustic_symbol_alphabet_is_nibbles :
    acousticFrameSpec.symbolBits = 4 ∧
    acousticFrameSpec.symbolAlphabet = 16 := by
  decide

structure IsolationBoundaryEvidence where
  networkDisconnected : Bool
  acousticChannelObserved : Bool
deriving DecidableEq, Repr

/--
A network air gap is not equivalent to "no communication path".
Observed out-of-band communication refutes that stronger claim.
-/
def noCommunicationPathClaim
    (e : IsolationBoundaryEvidence) : Prop :=
  e.networkDisconnected = true ∧
  e.acousticChannelObserved = false

theorem acoustic_side_channel_refutes_total_isolation
    (e : IsolationBoundaryEvidence)
    (hAcoustic : e.acousticChannelObserved = true) :
    ¬ noCommunicationPathClaim e := by
  intro h
  rw [hAcoustic] at h
  simp at h


/-
-------------------------------------------------------------------------------
F. CORPUS SUPPORT WRAPPER AROUND THE CURRENT MAIN KERNEL
-------------------------------------------------------------------------------
-/

structure CorpusAlignmentState where
  base       : AlignedKernel
  corpusRoot : String
  deposits   : Ledger String
  claimTiers : Ledger CorpusClaimTier
deriving Repr

def CorpusAlignmentLaw
    (before after : CorpusAlignmentState) : Prop :=
  AlignedKernelLaw before.base after.base ∧
  before.corpusRoot = after.corpusRoot ∧
  before.deposits.entries.length ≤ after.deposits.entries.length ∧
  before.claimTiers.entries.length ≤ after.claimTiers.entries.length

theorem corpus_alignment_preserves_root
    (before after : CorpusAlignmentState)
    (h : CorpusAlignmentLaw before after) :
    before.base.durable.core.root = after.base.durable.core.root := by
  exact aligned_law_preserves_root before.base after.base h.1

theorem corpus_alignment_preserves_manifest_root
    (before after : CorpusAlignmentState)
    (h : CorpusAlignmentLaw before after) :
    before.corpusRoot = after.corpusRoot := by
  exact h.2.1

/--
Content integrity, corpus signature, claim tags, observer metaphors, and
side-channel demonstrations are all support evidence. None of them bypasses
DurableKernelLaw or the verified-only truth advancement rule.
-/

/-
End corpus / airgap / lepton-photon alignment v20.
-/


/-
===============================================================================
ANALYTICAL ENGINE / STEAMPUNK CONTROL PLANE ALIGNMENT — v21
Source: index(20261007-183642).html + README
Fold date: 2026-10-07

Classification:
  TEST_FIXTURE + STATE-MACHINE ANCESTRY

The uploaded artifact is explicitly described by its README as a prototype
"render-not-invent."  Its useful content is therefore the executable eight-slot
state machine, not a claim of historical Babbage fidelity.

Promoted:
  * eight indexed slots/gears
  * cold -> ignited seed transition
  * deterministic /r/ rotation
  * boundary events at internal positions 3 and 6
  * append-like activation of visited slots
  * bounded pressure accumulator
  * explicit shadow -> reveal transition
  * vent/resource-release transition
  * punch-card state projection

Not promoted:
  * steampunk UI
  * pressure/cubi as physical quantities
  * "Ada's Law" label as a historical theorem
  * random shadow selection as authority
  * unused local hash helper as integrity security
  * any implication that this prototype is a faithful Babbage emulator

This remains a fixture around the current OASIS kernel, never a replacement for
KernelLaw, DurableKernelLaw, AlignedKernelLaw, or CorpusAlignmentLaw.
===============================================================================
-/

def analyticalEngineAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Analytical Engine · Steampunk Control Plane"
    disposition := .testFixture
    target := "AnalyticalEngineFixture"
    note := "8-slot rotational state machine with boundary, shadow, reveal, vent and punch-card projection" }

def legacyAlignmentCatalogV21 : List LegacyAlignmentEntry :=
  legacyAlignmentCatalogV19 ++ [analyticalEngineAlignmentEntry]

theorem legacy_alignment_catalog_v21_count :
    legacyAlignmentCatalogV21.length = 9 := by
  decide


inductive AnalyticalSlotState where
  | idle
  | seed
  | active
  | shadow
deriving DecidableEq, Repr

structure AnalyticalEngineFixture where
  ignited    : Bool
  position   : Nat
  cubi       : Nat
  boundaries : Nat
  active     : List Nat
  shadows    : List Nat
  pressure10 : Nat
  cycles     : Nat
deriving DecidableEq, Repr

/--
pressure10 stores tenths so the formal fixture avoids floating-point semantics.
Source pressure 1.0 is represented as 10, +0.1 as +1, +0.5 as +5, etc.
-/
def analyticalCold : AnalyticalEngineFixture :=
  { ignited := false
    position := 0
    cubi := 0
    boundaries := 0
    active := []
    shadows := []
    pressure10 := 0
    cycles := 0 }

def analyticalIgnite (_ : AnalyticalEngineFixture) : AnalyticalEngineFixture :=
  { ignited := true
    position := 0
    cubi := 1
    boundaries := 1
    active := [0]
    shadows := []
    pressure10 := 10
    cycles := 0 }

theorem analytical_ignite_seed :
    analyticalIgnite analyticalCold =
      { ignited := true
        position := 0
        cubi := 1
        boundaries := 1
        active := [0]
        shadows := []
        pressure10 := 10
        cycles := 0 } := by
  rfl

def insertNatUnique (x : Nat) (xs : List Nat) : List Nat :=
  if x ∈ xs then xs else xs ++ [x]

def analyticalBoundaryPosition (p : Nat) : Bool :=
  p = 3 || p = 6

def analyticalCalculate (e : AnalyticalEngineFixture) : AnalyticalEngineFixture :=
  if !e.ignited then e
  else
    let p := (e.position + 1) % 8
    let crossed := analyticalBoundaryPosition p
    { ignited := e.ignited
      position := p
      cubi := if crossed then e.cubi + 1 else e.cubi
      boundaries := if crossed then e.boundaries + 1 else e.boundaries
      active := insertNatUnique p e.active
      shadows := e.shadows
      pressure10 := min 100 (e.pressure10 + 1)
      cycles := if p = 0 then e.cycles + 1 else e.cycles }

def analyticalRunN : Nat → AnalyticalEngineFixture → AnalyticalEngineFixture
  | 0, e => e
  | n+1, e => analyticalRunN n (analyticalCalculate e)

theorem analytical_eight_step_cycle :
    let e := analyticalRunN 8 (analyticalIgnite analyticalCold)
    e.position = 0 ∧
    e.cubi = 3 ∧
    e.boundaries = 3 ∧
    e.pressure10 = 18 ∧
    e.active = [0,1,2,3,4,5,6,7] ∧
    e.cycles = 1 := by
  decide

/--
Source shadow insertion picks a random currently inactive slot.
The formal fixture factors randomness out: the caller supplies the slot and the
transition accepts it only when it is in range, inactive, and not already shadow.
-/
def analyticalCanShadow (e : AnalyticalEngineFixture) (slot : Nat) : Bool :=
  slot < 8 &&
  !(slot ∈ e.active) &&
  !(slot ∈ e.shadows)

def analyticalAddShadow
    (e : AnalyticalEngineFixture) (slot : Nat) : AnalyticalEngineFixture :=
  if analyticalCanShadow e slot then
    { e with
      shadows := e.shadows ++ [slot]
      pressure10 := e.pressure10 + 5 }
  else e

def analyticalReveal (e : AnalyticalEngineFixture) : AnalyticalEngineFixture :=
  let n := e.shadows.length
  { e with
    active := e.shadows.foldl (fun xs x => insertNatUnique x xs) e.active
    shadows := []
    pressure10 := e.pressure10 - (4 * n) }

def analyticalVent (e : AnalyticalEngineFixture) : AnalyticalEngineFixture :=
  if e.pressure10 < 10 then e
  else
    { e with
      pressure10 := e.pressure10 - 10
      cubi := max 1 (e.cubi - 1) }

def analyticalHolonomy (e : AnalyticalEngineFixture) : Int :=
  Int.ofNat e.active.length - Int.ofNat e.shadows.length

/--
Punch-card projection from the source: a bit is punched iff the corresponding
slot is active.  This is a projection of state, not a cryptographic commitment.
-/
def analyticalPunchCard (e : AnalyticalEngineFixture) : List Bool :=
  (List.range 8).map (fun i => decide (i ∈ e.active))

theorem analytical_punch_card_width (e : AnalyticalEngineFixture) :
    (analyticalPunchCard e).length = 8 := by
  simp [analyticalPunchCard]

/--
The local JavaScript includes an FNV-1a-style helper named `hash`, but the
uploaded state machine never calls it.  It is deliberately not treated as a
durable content-address or integrity primitive.
-/

/--
Like the geometric fixture, this prototype never self-authorizes.
Its execution may generate test evidence, but durable authority still comes
from the current kernel.
-/
def analyticalFixtureGate (_ : AnalyticalEngineFixture) : DurableGate :=
  .hold

theorem analytical_fixture_does_not_self_authorize
    (e : AnalyticalEngineFixture) :
    analyticalFixtureGate e = .hold := by
  rfl

/-
End Analytical Engine alignment v21.
-/


/-
===============================================================================
ARGUS-IN-A-BOX ALIGNMENT — v22
Source: index(20261007-184140).html
Fold date: 2026-10-07

Classification:
  GOVERNANCE SUPPORT PROTOCOL

The source explicitly defines Argus as:
  * a conceptual protocol, not an agent
  * task/session scoped
  * no persistence
  * no background monitoring
  * no external actions
  * human-gated resumption after a pause

Operationally valuable content:
  * eight named wandering signals W0..W7
  * immediate-pause tier: W0, W2, W3, W5
  * low-confidence tier: W1, W4, W6, W7
  * pause on any immediate signal OR two or more low-tier signals
  * no autonomous continuation after pause
  * explicit human resume inputs
  * strict terminal pause-report marker

Alignment rule:
  Argus may CLOSE/HOLD work.
  Argus may not OPEN durable authority.
  Resume requires explicit human re-authorization evidence.
===============================================================================
-/

def argusAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Argus-in-a-Box v1.1-BATTLEPROOF"
    disposition := .support
    target := "ArgusControlPlane"
    note := "human-gated drift detector; ambiguity resolves to pause, never autonomous escalation" }

def legacyAlignmentCatalogV22 : List LegacyAlignmentEntry :=
  legacyAlignmentCatalogV21 ++ [argusAlignmentEntry]

theorem legacy_alignment_catalog_v22_count :
    legacyAlignmentCatalogV22.length = 10 := by
  decide


inductive ArgusSignal where
  | W0  -- undefined objective / metrics
  | W1  -- non-improving revision loop
  | W2  -- goal drift
  | W3  -- fluency over truth
  | W4  -- churn editing
  | W5  -- contradiction growth
  | W6  -- scope creep
  | W7  -- speculation creep
deriving DecidableEq, Repr

def argusImmediate : ArgusSignal → Bool
  | .W0 => true
  | .W2 => true
  | .W3 => true
  | .W5 => true
  | _   => false

def argusLow : ArgusSignal → Bool
  | .W1 => true
  | .W4 => true
  | .W6 => true
  | .W7 => true
  | _   => false

def argusLowCount : List ArgusSignal → Nat
  | [] => 0
  | s :: ss => (if argusLow s then 1 else 0) + argusLowCount ss

def argusHasImmediate (xs : List ArgusSignal) : Bool :=
  xs.any argusImmediate

def argusPauseRequired (xs : List ArgusSignal) : Bool :=
  argusHasImmediate xs || decide (2 ≤ argusLowCount xs)

theorem argus_W0_immediate :
    argusPauseRequired [.W0] = true := by
  decide

theorem argus_W2_immediate :
    argusPauseRequired [.W2] = true := by
  decide

theorem argus_W3_immediate :
    argusPauseRequired [.W3] = true := by
  decide

theorem argus_W5_immediate :
    argusPauseRequired [.W5] = true := by
  decide

theorem argus_one_low_does_not_force_pause :
    argusPauseRequired [.W1] = false := by
  decide

theorem argus_two_low_force_pause :
    argusPauseRequired [.W1, .W4] = true := by
  decide

theorem argus_empty_signal_set_does_not_pause :
    argusPauseRequired [] = false := by
  decide


inductive ArgusDisposition where
  | continue
  | monitor
  | pause
deriving DecidableEq, Repr

def argusDisposition (xs : List ArgusSignal) : ArgusDisposition :=
  if argusPauseRequired xs then .pause
  else if argusLowCount xs = 1 then .monitor
  else .continue

theorem argus_single_low_monitors :
    argusDisposition [.W6] = .monitor := by
  decide

theorem argus_immediate_pauses :
    argusDisposition [.W3] = .pause := by
  decide


structure ArgusResumeInput where
  goalConfirmed       : Bool
  measurableCriteria  : Nat
  constraintsConfirmed : Bool
  nextStepApproved    : Bool
deriving DecidableEq, Repr

def argusMayResume (r : ArgusResumeInput) : Bool :=
  r.goalConfirmed &&
  decide (0 < r.measurableCriteria) &&
  r.constraintsConfirmed &&
  r.nextStepApproved

theorem argus_resume_requires_criterion
    (g c n : Bool) :
    argusMayResume
      { goalConfirmed := g
        measurableCriteria := 0
        constraintsConfirmed := c
        nextStepApproved := n } = false := by
  cases g <;> cases c <;> cases n <;> decide

theorem argus_complete_resume_input_allows_resume :
    argusMayResume
      { goalConfirmed := true
        measurableCriteria := 1
        constraintsConfirmed := true
        nextStepApproved := true } = true := by
  decide


def argusTerminalLine : String :=
  "=== END PAUSE REPORT ==="

structure ArgusPauseReportShape where
  hasSignalList       : Bool
  hasCurrentGoal      : Bool
  hasSuccessCriteria  : Bool
  hasLastThreeChanges : Bool
  hasMeasuredBenefit  : Bool
  hasOpenQuestions    : Bool
  hasHumanRequest     : Bool
  terminalLine        : String
deriving DecidableEq, Repr

def argusRequiredPauseShape : ArgusPauseReportShape :=
  { hasSignalList := true
    hasCurrentGoal := true
    hasSuccessCriteria := true
    hasLastThreeChanges := true
    hasMeasuredBenefit := true
    hasOpenQuestions := true
    hasHumanRequest := true
    terminalLine := argusTerminalLine }

theorem argus_pause_terminal_is_fixed :
    argusRequiredPauseShape.terminalLine = "=== END PAUSE REPORT ===" := by
  rfl


/--
Argus closes authority; it never grants it.
Any pause maps to HOLD at the durable boundary.
-/ 
def argusGate (signals : List ArgusSignal) : DurableGate :=
  if argusPauseRequired signals then .hold else .hold

theorem argus_never_self_opens
    (signals : List ArgusSignal) :
    argusGate signals ≠ .open := by
  unfold argusGate
  split <;> decide


/--
A task-local wrapper around the current main kernel.
`humanEpoch` is an abstract monotonic witness supplied by the integrating host;
Argus itself does not create or persist it.
-/
structure ArgusControlPlane where
  base        : CorpusAlignmentState
  paused      : Bool
  signals     : List ArgusSignal
  humanEpoch  : Nat
deriving Repr

def ArgusControlLaw
    (before after : ArgusControlPlane) : Prop :=
  CorpusAlignmentLaw before.base after.base ∧
  (before.paused = true ∧ after.paused = false →
    before.humanEpoch < after.humanEpoch)

theorem argus_control_preserves_root
    (before after : ArgusControlPlane)
    (h : ArgusControlLaw before after) :
    before.base.base.durable.core.root =
      after.base.base.durable.core.root := by
  exact corpus_alignment_preserves_root before.base after.base h.1

theorem argus_resume_requires_new_human_epoch
    (before after : ArgusControlPlane)
    (h : ArgusControlLaw before after)
    (hp : before.paused = true)
    (hr : after.paused = false) :
    before.humanEpoch < after.humanEpoch := by
  exact h.2 ⟨hp, hr⟩

/--
This formalization intentionally does not implement background monitoring.
The host explicitly invokes `argusPauseRequired` for the current task/session.
-/


/-
End Argus alignment v22.
-/


/-
===============================================================================
TERNARY ±211 ARTIFACT ALIGNMENT — v23
Source: uploaded "wakaku v161 bit itself -211.1.+211" artifact
Fold date: 2026-10-07

Classification:
  TEST_FIXTURE + NUMERIC-LABEL TAXONOMY

Useful content:
  * a three-state carrier
  * artifact labels: -211 / 1 / +211
  * semantic balanced-ternary interpretation: -1 / 0 / +1
  * intended clock path: -1 -> 0 -> +1 -> 0 -> -1
  * explicit distinction between ingress / neutral hold / egress roles

Critical boundary:
  The artifact also attaches physical labels such as mV, mN, At-/anti-At,
  matter/antimatter, C.O.I.N., and "qutrit". Those labels are NOT promoted as
  physics claims. No measurement provenance, calibration chain, quantum state,
  or experimental apparatus is encoded in the artifact.

  In particular, ±211 is preserved as an artifact code / candidate measurement
  value, not as a universal physical constant.

Implementation note:
  The uploaded page's `makeGraph(id, fn, color)` helper is called with a string
  in the `fn` position, while the body later executes `fn(t)`. Therefore the
  three small graph panels are structurally broken as written. The Three.js
  state visualization is separable from that defect.
===============================================================================
-/

def ternary211AlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "wakaku v161 / ±211 ternary artifact"
    disposition := .testFixture
    target := "Ternary211State / ternary211Clock"
    note := "three-state ingress/hold/egress fixture; physical-unit labels remain unverified metadata" }

def legacyAlignmentCatalogV23 : List LegacyAlignmentEntry :=
  legacyAlignmentCatalogV22 ++ [ternary211AlignmentEntry]

theorem legacy_alignment_catalog_v23_count :
    legacyAlignmentCatalogV23.length = 11 := by
  decide


inductive Ternary211State where
  | negative
  | neutral
  | positive
deriving DecidableEq, Repr

/--
Artifact-facing code.  The middle label is literally `1` in the source.
This is intentionally kept distinct from the semantic balanced-ternary value.
-/
def ternary211ArtifactCode : Ternary211State → Int
  | .negative => -211
  | .neutral  => 1
  | .positive => 211

/-- Semantic balanced-ternary value. -/
def ternary211BalancedValue : Ternary211State → Int
  | .negative => -1
  | .neutral  => 0
  | .positive => 1

theorem ternary211_middle_label_is_not_semantic_zero :
    ternary211ArtifactCode .neutral = 1 ∧
    ternary211BalancedValue .neutral = 0 := by
  decide

theorem ternary211_negative_mapping :
    ternary211ArtifactCode .negative = -211 ∧
    ternary211BalancedValue .negative = -1 := by
  decide

theorem ternary211_positive_mapping :
    ternary211ArtifactCode .positive = 211 ∧
    ternary211BalancedValue .positive = 1 := by
  decide


inductive Ternary211Role where
  | ingress
  | hold
  | egress
deriving DecidableEq, Repr

def ternary211Role : Ternary211State → Ternary211Role
  | .negative => .ingress
  | .neutral  => .hold
  | .positive => .egress

theorem ternary211_role_order :
    [ ternary211Role .negative
    , ternary211Role .neutral
    , ternary211Role .positive ] =
    [.ingress, .hold, .egress] := by
  rfl


/-- Intended oscillation stated by the artifact. -/
def ternary211Clock : List Ternary211State :=
  [.negative, .neutral, .positive, .neutral, .negative]

theorem ternary211_clock_length :
    ternary211Clock.length = 5 := by
  decide

theorem ternary211_clock_returns_to_origin :
    ternary211Clock.head? = some .negative ∧
    ternary211Clock.getLast? = some .negative := by
  decide

theorem ternary211_clock_balanced_values :
    ternary211Clock.map ternary211BalancedValue = [-1,0,1,0,-1] := by
  decide


/--
A possible measured voltage is separated from the state label.
Evidence/provenance are mandatory fields before a measurement can be reviewed.
-/
structure MillivoltObservation where
  millivolts : Int
  source     : String
  evidenceId : Id
deriving DecidableEq, Repr

def isArtifact211Magnitude (o : MillivoltObservation) : Bool :=
  o.millivolts = -211 || o.millivolts = 211

/--
Even an exact ±211 mV observation is only a candidate until its apparatus,
reference electrode / electrical reference, calibration, time, and raw evidence
are independently checked.
-/
def ternary211ObservationState (o : MillivoltObservation) : CandidateState :=
  if isArtifact211Magnitude o then .quarantined else .non_aligned

theorem ternary211_measurement_never_auto_verifies
    (o : MillivoltObservation) :
    ternary211ObservationState o ≠ .verified := by
  unfold ternary211ObservationState
  split <;> decide


/--
This artifact cannot self-authorize durable kernel state.
-/
def ternary211Gate (_ : Ternary211State) : DurableGate :=
  .hold

theorem ternary211_never_self_opens
    (s : Ternary211State) :
    ternary211Gate s ≠ .open := by
  decide

/-
End ternary ±211 alignment v23.
-/


/-
===============================================================================
ATOMIC FAMILY ALIGNMENT — v24
Sources:
  * atomic map v1.html
  * atomic map v2.html
  * atomic workshop v1.html
  * laporte-dust.json
  * valence-lattice.html
  * valence-atom.html
  * the-atom-instrument.html
Fold date: 2026-10-07

Classification:
  Atomic Map v1/v2       TEST FIXTURE
  Atomic Workshop v1     ARCHIVE / TAXONOMY
  LAPORTE-DUST v1.0      TEST FIXTURE / ADDRESS INVARIANT
  Valence Lattice        TEST FIXTURE / ADDRESSING
  Valence Atom           TEST FIXTURE / ADDRESSING + PARITY WITNESS
  The Atom Instrument    SUPPORT / APPEND-ONLY WITNESS STATE MACHINE

Boundary:
  * Address spaces and state machines are admitted.
  * Chemistry/particle names used as seeded labels are not detections.
  * "257 NULL" is not promoted as a physical law.
  * Hash identity proves record integrity, not physical truth.
  * Physics analogies do not bypass CandidateState review.
===============================================================================
-/

def atomicMapV1AlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Atomic Map v1"
    disposition := .testFixture
    target := "atomicMapRuntimeValues100 / atomicMapRuntimeDeltas100"
    note := "ring-sequence fixture; source label says 0.02 first delta but runtime uses 1.02" }

def atomicMapV2AlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Atomic Map v2"
    disposition := .testFixture
    target := "AtomicMapVmFixture"
    note := "vm1 eject / seed-armed visualization; cost and Merkle labels are artifact-local" }

def atomicWorkshopAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Atomic Workshop v1"
    disposition := .archive
    target := "AtomicWorkshopTaxonomy"
    note := "1–118 table plus speculative 119–256/257 taxonomy; no physical invariant promotion" }

def laporteDustAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "LAPORTE-DUST v1.0"
    disposition := .testFixture
    target := "LaporteDustSpec"
    note := "7-ary recursive address fixture with parity alternation metadata" }

def valenceLatticeAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Valence Lattice"
    disposition := .testFixture
    target := "valenceLatticeDigits"
    note := "deterministic recursive decimal addressing; seeded names are not detections" }

def valenceAtomAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "Valence Atom"
    disposition := .testFixture
    target := "valenceAtomDigits / DustParity"
    note := "core/valence/parity address fixture; chemistry comparison remains labeled analogy" }

def atomInstrumentAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "The Atom Instrument"
    disposition := .support
    target := "AtomWitnessSupport"
    note := "56-state shell fixture, Δn=±1 transition gate, uniqueness, append-only hash-linked witness records" }

def legacyAlignmentCatalogV24 : List LegacyAlignmentEntry :=
  legacyAlignmentCatalogV23 ++
  [ atomicMapV1AlignmentEntry
  , atomicMapV2AlignmentEntry
  , atomicWorkshopAlignmentEntry
  , laporteDustAlignmentEntry
  , valenceLatticeAlignmentEntry
  , valenceAtomAlignmentEntry
  , atomInstrumentAlignmentEntry
  ]

theorem legacy_alignment_catalog_v24_count :
    legacyAlignmentCatalogV24.length = 18 := by
  decide


/-
-------------------------------------------------------------------------------
A. ATOMIC MAP v1/v2 — RUNTIME SEQUENCE FIXTURE
-------------------------------------------------------------------------------
-/

/-- Hundredths, to preserve the source's decimal data without floating point. -/
def atomicMapRuntimeValues100 : List Int :=
  [200, 98, 94, 78, 46, -18, -146, -402, -914, -1938, -3986]

def atomicMapRuntimeDeltas100 : List Nat :=
  [0, 102, 4, 16, 32, 64, 128, 256, 512, 1024, 2048]

def atomicMapRadii100 : List Nat :=
  [0, 102, 204, 306, 408, 510, 612, 714, 816, 918, 1020]

theorem atomic_map_sequence_width :
    atomicMapRuntimeValues100.length = 11 ∧
    atomicMapRuntimeDeltas100.length = 11 ∧
    atomicMapRadii100.length = 11 := by
  decide

/--
The visible formula card says the first delta is 0.02, while the JavaScript
runtime uses 1.02 to move 2.00 -> 0.98.  Preserve the discrepancy explicitly.
-/
def atomicMapDisplayedFirstDelta100 : Nat := 2
def atomicMapRuntimeFirstDelta100 : Nat := 102

theorem atomic_map_first_delta_source_discrepancy :
    atomicMapDisplayedFirstDelta100 ≠ atomicMapRuntimeFirstDelta100 := by
  decide


structure AtomicMapVmFixture where
  vm1Active : Bool
  seedArmed : Bool
  cost100   : Nat
deriving DecidableEq, Repr

def atomicMapVmInitial : AtomicMapVmFixture :=
  { vm1Active := true, seedArmed := false, cost100 := 2248 }

def atomicMapVmEject (_ : AtomicMapVmFixture) : AtomicMapVmFixture :=
  { vm1Active := false, seedArmed := true, cost100 := 200 }

theorem atomic_map_vm_eject_fixture :
    atomicMapVmEject atomicMapVmInitial =
      { vm1Active := false, seedArmed := true, cost100 := 200 } := by
  rfl

/--
The v2 page displays Merkle-like hexadecimal labels, but they are UI constants,
not computed commitments.  They are intentionally not imported here.
-/


/-
-------------------------------------------------------------------------------
B. ATOMIC WORKSHOP — ARCHIVAL NUMBERING TAXONOMY
-------------------------------------------------------------------------------
-/

structure AtomicWorkshopTaxonomy where
  observedUpperLabel    : Nat
  theoreticalLowerLabel : Nat
  theoreticalUpperLabel : Nat
  nullLabel             : Nat
deriving DecidableEq, Repr

def atomicWorkshopTaxonomy : AtomicWorkshopTaxonomy :=
  { observedUpperLabel := 118
    theoreticalLowerLabel := 119
    theoreticalUpperLabel := 256
    nullLabel := 257 }

theorem atomic_workshop_arithmetic_only :
    (List.range 256 |>.map (· + 1) |>.foldl (· + ·) 0) = 32896 := by
  decide

/--
The arithmetic sum is retained; the conclusion "257 = physical null terminator"
is not inferred from it.
-/


/-
-------------------------------------------------------------------------------
C. LAPORTE-DUST / DECIMAL ADDRESS FAMILIES
-------------------------------------------------------------------------------
-/

inductive DustParity where
  | even
  | odd
deriving DecidableEq, Repr

def flipDustParity : DustParity → DustParity
  | .even => .odd
  | .odd  => .even

theorem dust_parity_two_flips_restore (p : DustParity) :
    flipDustParity (flipDustParity p) = p := by
  cases p <;> rfl


structure DecimalDustSpec where
  name           : String
  activeDigits   : List Nat
  reservedDigits : List Nat
  axes           : Nat
  dimensionLabel : String
deriving DecidableEq, Repr

def laporteDustSpec : DecimalDustSpec :=
  { name := "LAPORTE-DUST v1.0"
    activeDigits := [2,3,4,5,6,7,8]
    reservedDigits := [0,1,9,10]
    axes := 1
    dimensionLabel := "log7/log10 = 0.8451" }

def valenceLatticeSpec : DecimalDustSpec :=
  { name := "Valence Lattice"
    activeDigits := [3,4,5,6,7,8]
    reservedDigits := [0,1,2,9]
    axes := 2
    dimensionLabel := "log36/log10 = 1.5563" }

def valenceAtomSpec : DecimalDustSpec :=
  { name := "Valence Atom"
    activeDigits := [4,5,6,7,8]
    reservedDigits := [0,1,2,3,9]
    axes := 2
    dimensionLabel := "log25/log10 = 1.39794" }

def atomInstrumentDustSpec : DecimalDustSpec :=
  { name := "Atom Instrument Lattice"
    activeDigits := [2,3,4,5,6,7,8]
    reservedDigits := [0,1,9,10]
    axes := 2
    dimensionLabel := "log49/log10 = 1.6902" }

theorem laporte_active_digit_count :
    laporteDustSpec.activeDigits.length = 7 := by
  decide

theorem laporte_depth8_state_count :
    7 ^ 8 = 5764801 := by
  decide

theorem valence_lattice_branch_count :
    valenceLatticeSpec.activeDigits.length ^ 2 = 36 := by
  decide

theorem valence_atom_branch_count :
    valenceAtomSpec.activeDigits.length ^ 2 = 25 := by
  decide

theorem atom_instrument_branch_count :
    atomInstrumentDustSpec.activeDigits.length ^ 2 = 49 := by
  decide


structure DecimalPairAddress where
  digits : List (Nat × Nat)
deriving DecidableEq, Repr

def appendDecimalPair
    (a : DecimalPairAddress)
    (h v : Nat) : DecimalPairAddress :=
  { digits := a.digits ++ [(h,v)] }

theorem append_decimal_pair_increases_depth
    (a : DecimalPairAddress)
    (h v : Nat) :
    (appendDecimalPair a h v).digits.length = a.digits.length + 1 := by
  simp [appendDecimalPair]


/-
-------------------------------------------------------------------------------
D. THE ATOM INSTRUMENT — 56-STATE TRANSITION/WITNESS FIXTURE
-------------------------------------------------------------------------------
-/

inductive AtomSide where
  | left
  | right
deriving DecidableEq, Repr

inductive AtomQuadrant where
  | ul
  | ur
  | lr
  | ll
deriving DecidableEq, Repr

structure AtomSlot where
  shell : Nat
  side  : AtomSide
  quad  : AtomQuadrant
deriving DecidableEq, Repr

def atomUsableShells : List Nat := [2,3,4,5,6,7,8]
def atomSides : List AtomSide := [.left, .right]
def atomQuadrants : List AtomQuadrant := [.ul, .ur, .lr, .ll]

def atomUsableSlots : List AtomSlot :=
  atomUsableShells.flatMap (fun n =>
    atomSides.flatMap (fun s =>
      atomQuadrants.map (fun q =>
        { shell := n, side := s, quad := q })))

theorem atom_usable_slot_count :
    atomUsableSlots.length = 56 := by
  decide


def AtomShellAdjacent (a b : Nat) : Prop :=
  a + 1 = b ∨ b + 1 = a

theorem atom_shell_adjacency_symmetric
    (a b : Nat)
    (h : AtomShellAdjacent a b) :
    AtomShellAdjacent b a := by
  exact Or.symm h


structure AtomElectron where
  id   : Id
  slot : AtomSlot
deriving DecidableEq, Repr

def AtomUniqueOccupancy (xs : List AtomElectron) : Prop :=
  ∀ a ∈ xs, ∀ b ∈ xs, a.id ≠ b.id → a.slot ≠ b.slot


inductive AtomWitnessEvent where
  | genesis
  | transition
  | ionize
  | bond
deriving DecidableEq, Repr

structure AtomWitnessReceipt where
  seq      : Nat
  event    : AtomWitnessEvent
  prevHash : String
  hash     : String
deriving DecidableEq, Repr

abbrev AtomWitnessLedger := Ledger AtomWitnessReceipt

def appendAtomWitness
    (l : AtomWitnessLedger)
    (r : AtomWitnessReceipt) : AtomWitnessLedger :=
  append l r

theorem atom_witness_append_preserves_prefix
    (l : AtomWitnessLedger)
    (r : AtomWitnessReceipt) :
    (appendAtomWitness l r).entries.take l.entries.length = l.entries := by
  simpa [appendAtomWitness] using
    (append_preserves_prefix l r)


inductive AtomBondLatch where
  | undecided
  | bonded
deriving DecidableEq, Repr

def atomBondOnce : AtomBondLatch → AtomBondLatch
  | .undecided => .bonded
  | .bonded    => .bonded

theorem atom_bond_is_monotonic :
    atomBondOnce .bonded = .bonded := by
  rfl


/--
No atom fixture or seeded element label may self-authorize current durable state.
-/
def atomInstrumentGate (_ : AtomWitnessLedger) : DurableGate :=
  .hold

theorem atom_instrument_never_self_opens
    (l : AtomWitnessLedger) :
    atomInstrumentGate l ≠ .open := by
  decide


/-
-------------------------------------------------------------------------------
E. MAIN-KERNEL SUPPORT WRAPPER
-------------------------------------------------------------------------------
-/

structure AtomWitnessSupport where
  base       : ArgusControlPlane
  witnesses  : AtomWitnessLedger
  bond       : AtomBondLatch
deriving Repr

def AtomWitnessSupportLaw
    (before after : AtomWitnessSupport) : Prop :=
  ArgusControlLaw before.base after.base ∧
  before.witnesses.entries.length ≤ after.witnesses.entries.length ∧
  (before.bond = .bonded → after.bond = .bonded)

theorem atom_support_preserves_root
    (before after : AtomWitnessSupport)
    (h : AtomWitnessSupportLaw before after) :
    before.base.base.base.durable.core.root =
      after.base.base.base.durable.core.root := by
  exact argus_control_preserves_root before.base after.base h.1

theorem atom_support_preserves_bond
    (before after : AtomWitnessSupport)
    (h : AtomWitnessSupportLaw before after)
    (hb : before.bond = .bonded) :
    after.bond = .bonded := by
  exact h.2.2 hb

/-
End atomic-family alignment v24.
-/


/-
===============================================================================
CROSS-KERNEL FALLOUT ALIGNMENT — v25
Fold date: 2026-10-07

This section records only relationships that fall out from already-admitted
v24 structures.  It does not add new physical claims.

Main results:
  1. LAPORTE-DUST depth 8 and the Atom Instrument's 7×7 pair-address space at
     depth 4 have exactly the same finite cardinality:
       7^8 = 49^4 = 5,764,801.
  2. Their address shapes have a direct pairing interpretation:
       8 one-axis base-7 digits <-> 4 ordered pairs of base-7 digits.
  3. The related active-band families are strictly nested:
       {4..8} ⊂ {3..8} ⊂ {2..8}
     yielding per-depth 2D branch counts:
       25 < 36 < 49.
  4. Atom quadrant mirroring is an involution.
  5. Source/runtime disagreement remains review evidence, never verification.
  6. Witness integrity remains distinct from durable authority.

No claim of physical equivalence, quantum isomorphism, or atomic discovery
follows from these structural equalities.
===============================================================================
-/

def falloutAlignmentEntry : LegacyAlignmentEntry :=
  { artifact := "v24 cross-kernel fallout"
    disposition := .support
    target := "FalloutAlignmentLaw"
    note := "structural relationships among recursive address spaces, witnesses, and current authority boundary" }

def legacyAlignmentCatalogV25 : List LegacyAlignmentEntry :=
  legacyAlignmentCatalogV24 ++ [falloutAlignmentEntry]

theorem legacy_alignment_catalog_v25_count :
    legacyAlignmentCatalogV25.length = 19 := by
  decide


/-
-------------------------------------------------------------------------------
A. LAPORTE <-> ATOM PAIR-ADDRESS CARDINALITY
-------------------------------------------------------------------------------
-/

def laporteDepth8Cardinality : Nat := 7 ^ 8
def atomPairDepth4Cardinality : Nat := 49 ^ 4

theorem laporte_atom_pair_cardinality_equal :
    laporteDepth8Cardinality = atomPairDepth4Cardinality := by
  decide

theorem laporte_atom_pair_cardinality_value :
    laporteDepth8Cardinality = 5764801 ∧
    atomPairDepth4Cardinality = 5764801 := by
  decide

/--
This is a finite address-shape equality only:
eight base-7 digits can be grouped into four ordered pairs.
-/


/-
-------------------------------------------------------------------------------
B. ACTIVE-BAND NESTING
-------------------------------------------------------------------------------
-/

def atomInstrumentActiveDigits : List Nat := [2,3,4,5,6,7,8]
def valenceLatticeActiveDigits : List Nat := [3,4,5,6,7,8]
def valenceAtomActiveDigits : List Nat := [4,5,6,7,8]

theorem valence_atom_digits_subset_lattice :
    ∀ x ∈ valenceAtomActiveDigits, x ∈ valenceLatticeActiveDigits := by
  decide

theorem valence_lattice_digits_subset_atom_instrument :
    ∀ x ∈ valenceLatticeActiveDigits, x ∈ atomInstrumentActiveDigits := by
  decide

def twoAxisBranchCount (digits : List Nat) : Nat :=
  digits.length ^ 2

theorem nested_band_branch_counts :
    twoAxisBranchCount valenceAtomActiveDigits = 25 ∧
    twoAxisBranchCount valenceLatticeActiveDigits = 36 ∧
    twoAxisBranchCount atomInstrumentActiveDigits = 49 := by
  decide

theorem nested_band_branch_counts_strict :
    twoAxisBranchCount valenceAtomActiveDigits <
      twoAxisBranchCount valenceLatticeActiveDigits ∧
    twoAxisBranchCount valenceLatticeActiveDigits <
      twoAxisBranchCount atomInstrumentActiveDigits := by
  decide


/-
-------------------------------------------------------------------------------
C. MIRROR INVOLUTION
-------------------------------------------------------------------------------
-/

def mirrorAtomQuadrant : AtomQuadrant → AtomQuadrant
  | .ul => .lr
  | .lr => .ul
  | .ur => .ll
  | .ll => .ur

theorem atom_quadrant_mirror_involution
    (q : AtomQuadrant) :
    mirrorAtomQuadrant (mirrorAtomQuadrant q) = q := by
  cases q <;> rfl


/-
-------------------------------------------------------------------------------
D. SOURCE CONSISTENCY IS REVIEW EVIDENCE
-------------------------------------------------------------------------------
-/

inductive SourceConsistency where
  | consistent
  | discrepant
deriving DecidableEq, Repr

def sourceConsistencyCandidateState : SourceConsistency → CandidateState
  | .consistent  => .quarantined
  | .discrepant => .quarantined

/--
A consistent source still needs independent verification.
A discrepant source is preserved for review rather than silently corrected.
Neither state directly enters `verified`.
-/
theorem source_consistency_never_auto_verifies
    (s : SourceConsistency) :
    sourceConsistencyCandidateState s ≠ .verified := by
  cases s <;> decide

def atomicMapFirstDeltaConsistency : SourceConsistency :=
  if atomicMapDisplayedFirstDelta100 = atomicMapRuntimeFirstDelta100
  then .consistent
  else .discrepant

theorem atomic_map_first_delta_is_discrepant :
    atomicMapFirstDeltaConsistency = .discrepant := by
  decide


/-
-------------------------------------------------------------------------------
E. INTEGRITY / WITNESS / AUTHORITY SEPARATION
-------------------------------------------------------------------------------
-/

inductive EvidenceLayer where
  | address
  | witness
  | integrity
  | authority
deriving DecidableEq, Repr

/--
An append-only witness can establish provenance/integrity properties but does
not self-promote to durable authority.
-/
def witnessEvidenceGate (_ : AtomWitnessLedger) : DurableGate :=
  .hold

theorem witness_integrity_is_not_authority
    (l : AtomWitnessLedger) :
    witnessEvidenceGate l ≠ .open := by
  decide


/-
-------------------------------------------------------------------------------
F. FALLOUT WRAPPER
-------------------------------------------------------------------------------
-/

structure FalloutAlignmentState where
  base           : AtomWitnessSupport
  sourceStatus   : SourceConsistency
  addressWitness : DecimalPairAddress
deriving Repr

def FalloutAlignmentLaw
    (before after : FalloutAlignmentState) : Prop :=
  AtomWitnessSupportLaw before.base after.base ∧
  before.addressWitness.digits.length ≤ after.addressWitness.digits.length

theorem fallout_alignment_preserves_root
    (before after : FalloutAlignmentState)
    (h : FalloutAlignmentLaw before after) :
    before.base.base.base.base.durable.core.root =
      after.base.base.base.base.durable.core.root := by
  exact atom_support_preserves_root before.base after.base h.1

theorem fallout_alignment_preserves_bond
    (before after : FalloutAlignmentState)
    (h : FalloutAlignmentLaw before after)
    (hb : before.base.bond = .bonded) :
    after.base.bond = .bonded := by
  exact atom_support_preserves_bond before.base after.base h.1 hb

/-
End cross-kernel fallout alignment v25.
-/

end OASIS
